import { NextRequest } from 'next/server';
async function proxy(request: NextRequest, context: {params: Promise<{path:string[]}>}) {
  const allowed=['localhost','127.0.0.1','[::1]'];
  const host=request.headers.get('host')||'';
  if(!allowed.includes(new URL('http://'+host).hostname))return Response.json({detail:'Недопустимый адрес сервера'},{status:403});
  const origin=request.headers.get('origin');
  if(origin&&new URL(origin).host!==host)return Response.json({detail:'Недопустимый источник запроса'},{status:403});
  const {path}=await context.params;
  const base=process.env.OPTICS_API_URL || 'http://127.0.0.1:8765';
  try {
    const headers=new Headers();
    for (const name of ['content-type','cookie','origin']) { const value=request.headers.get(name); if(value) headers.set(name,value); }
    const response=await fetch(`${base}/${path.map(encodeURIComponent).join('/')}${request.nextUrl.search}`, {method:request.method,headers,body:['GET','HEAD'].includes(request.method)?undefined:await request.arrayBuffer()});
    const outgoing=new Headers();
    for(const name of ['content-type','content-disposition','set-cookie']) {const value=response.headers.get(name);if(value)outgoing.set(name,value);}
    return new Response(response.body,{status:response.status,headers:outgoing});
  } catch {return Response.json({detail:'Расчётный сервер недоступен. Запустите Python-сервис или настройте OPTICS_API_URL.'},{status:503});}
}
export const GET=proxy; export const POST=proxy; export const DELETE=proxy;
