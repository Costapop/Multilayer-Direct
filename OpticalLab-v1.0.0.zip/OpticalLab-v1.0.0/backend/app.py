from __future__ import annotations
import secrets, time, os
from concurrent.futures import ThreadPoolExecutor
from fastapi import FastAPI, HTTPException, Request, Response, UploadFile, File, Form
from fastapi.responses import FileResponse, JSONResponse
from urllib.parse import urlparse
from pydantic import BaseModel
from pathlib import Path
from . import library, excel_io, agent
from .models import Project, demo_project
from .solver import calculate, prepare, CORE_COMMIT
app=FastAPI(title='Optical Coating Lab',version='1.0.0')
@app.middleware('http')
async def local_origin_guard(request:Request,call_next):
    allowed={'localhost','127.0.0.1','::1','testserver'}
    if request.url.hostname not in allowed:return JSONResponse({'detail':'Недопустимый адрес сервера'},status_code=403)
    origin=request.headers.get('origin')
    if origin and (urlparse(origin).hostname not in allowed or urlparse(origin).scheme not in ['http','https']):return JSONResponse({'detail':'Недопустимый источник запроса'},status_code=403)
    return await call_next(request)

jobs={}; pool=ThreadPoolExecutor(max_workers=2); sessions={}
def session(request: Request, response: Response):
    sid=request.cookies.get('optics_session')
    if sid not in sessions:
        sid=secrets.token_urlsafe(32); sessions[sid]={}
        response.set_cookie('optics_session',sid,httponly=True,samesite='strict',max_age=43200)
    return sid,sessions[sid]
@app.get('/health')
def health(request:Request,response:Response):
    _,s=session(request,response)
    return {'status':'ok','core_commit':CORE_COMMIT,'ai_connected':bool(not s.get('disabled') and (s.get('key') or os.environ.get('OPENAI_API_KEY'))),'model':s.get('model',os.getenv('OPENAI_MODEL','gpt-5.4'))}
@app.get('/demo')
def demo(): return demo_project().model_dump()
@app.post('/validate')
def validate(project:Project):
    try: prepare(project)
    except (ValueError,TypeError,KeyError,ArithmeticError) as exc: raise HTTPException(422,str(exc))
    return {'valid':True,'layers':len(project.layers),'project':project.model_dump()}
@app.post('/jobs')
def start_job(project:Project,request:Request,response:Response):
    sid,_=session(request,response); validate(project)
    if sum(j['owner']==sid and j['status'] in ['queued','running'] for j in jobs.values())>=2: raise HTTPException(429,'Дождитесь или отмените предыдущий расчёт')
    for key in list(jobs):
        if time.time()-jobs[key]['created']>3600: jobs.pop(key,None)
    jid=secrets.token_urlsafe(18); job={'id':jid,'status':'queued','progress':0,'created':time.time(),'owner':sid,'cancel':False}; jobs[jid]=job
    def run():
        job['status']='running'
        try:
            result=calculate(project,lambda p:job.update(progress=p),lambda:job['cancel'])
            if job['cancel']: job['status']='cancelled'
            else: job.update(status='done',result=result)
        except InterruptedError: job['status']='cancelled'
        except Exception as exc: job.update(status='error',error=str(exc))
    pool.submit(run)
    return {'id':jid,'status':'queued'}
def owned_job(jid,request):
    job=jobs.get(jid)
    if not job or job['owner']!=request.cookies.get('optics_session'): raise HTTPException(404,'Расчёт не найден')
    return job
@app.get('/jobs/{jid}')
def get_job(jid:str,request:Request): return {k:v for k,v in owned_job(jid,request).items() if k not in ['owner','cancel']}
@app.delete('/jobs/{jid}')
def cancel_job(jid:str,request:Request):
    owned_job(jid,request)['cancel']=True
    return {'cancelled':True}

@app.post('/config')
def config(body:dict,request:Request,response:Response):
    _,s=session(request,response)
    if body.get('disconnect'):s.pop('key',None);s['disabled']=True
    elif body.get('api_key'):s['key']=str(body['api_key']).strip();s['disabled']=False
    if body.get('model'):s['model']=str(body['model']).strip()
    return {'connected':bool(not s.get('disabled') and (s.get('key') or os.getenv('OPENAI_API_KEY'))),'model':s.get('model',os.getenv('OPENAI_MODEL','gpt-5.4'))}

@app.get('/materials')
def material_search(q:str=''): return library.search(q)

@app.get('/materials/load')
def material_load(path:str):
    try:return library.load_material(path).model_dump()
    except Exception as exc:raise HTTPException(422,str(exc))

@app.post('/materials/preview')
def material_preview(body:dict):
    from .models import Material
    from .solver import material_function, evaluate_index
    import numpy as np
    try:
        m=Material.model_validate(body['material']);start,stop=m.range_um or [.4,.8]
        x=np.linspace(start,stop,81);v=evaluate_index(material_function(m),2*np.pi/x)
        return {'wavelength_nm':(x*1000).tolist(),'n':v.real.tolist(),'kappa':(-v.imag).tolist()}
    except Exception as exc:raise HTTPException(422,str(exc))

@app.get('/excel/template')
def template(): return FileResponse(Path(__file__).parent.parent/'public'/'coating-template.xlsx',filename='coating-template.xlsx')

@app.post('/excel/preview')
async def excel_preview(file:UploadFile=File(...)):
    try:return excel_io.preview(await file.read(12_000_001))
    except Exception as exc:raise HTTPException(422,str(exc))

@app.post('/excel/import')
async def excel_import(file:UploadFile=File(...),options:str=Form('{}')):
    import json
    try:
        opts=json.loads(options);content=await file.read(12_000_001)
        result=excel_io.import_mapped(content,opts['mapping'],opts['project']) if opts.get('mapping') else excel_io.import_standard(content,opts.get('variant'))
        if 'project' in result:prepare(Project.model_validate(result['project']))
        return result
    except Exception as exc:raise HTTPException(422,str(exc))

@app.post('/export/{fmt}')
def export(fmt:str,body:dict):
    if fmt not in ['xlsx','csv']:raise HTTPException(400,'Поддерживаются xlsx и csv')
    try:content=excel_io.export_results(body['calculations'],fmt)
    except Exception as exc:raise HTTPException(422,str(exc))
    mime='text/csv' if fmt=='csv' else 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    return Response(content,media_type=mime,headers={'Content-Disposition':f'attachment; filename="spectra.{fmt}"'})

@app.post('/chat')
def chat_request(body:dict,request:Request,response:Response):
    _,s=session(request,response)
    try:return agent.chat(str(body['message']),body.get('history',[]),Project.model_validate(body['project']),s)
    except Exception as exc:raise HTTPException(422,str(exc))
