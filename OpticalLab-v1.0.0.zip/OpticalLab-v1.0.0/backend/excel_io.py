"""Application runtime importer/exporter; never executes workbook macros or formulas."""
import io, json, uuid, csv, zipfile
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from .models import Project, Material, LayerInput, Settings, PlotInput, demo_project
from .library import load_material
UNITS={'нм':'nm','мкм':'um','µm':'um','μm':'um','мм':'mm','см':'cm','м':'m','nm':'nm','um':'um','mm':'mm','cm':'cm','m':'m'}
def number(v,cell):
    if isinstance(v,bool) or v is None: raise ValueError(f'{cell}: требуется число')
    try: return float(str(v).strip().replace(' ','').replace(',','.'))
    except (ValueError,TypeError): raise ValueError(f'{cell}: некорректное число «{v}»')
def integer(v,cell):
    n=number(v,cell)
    if not n.is_integer():raise ValueError(f'{cell}: требуется целое число')
    return int(n)
def workbook(content):
    if len(content)>12_000_000: raise ValueError('Файл слишком большой: максимум 12 МБ')
    with zipfile.ZipFile(io.BytesIO(content)) as z:
        if sum(i.file_size for i in z.infolist())>80_000_000: raise ValueError('Слишком большой распакованный Excel-файл')
    wb=load_workbook(io.BytesIO(content),data_only=True,read_only=False,keep_links=False)
    if sum(s.max_row*s.max_column for s in wb)>300_000: raise ValueError('Слишком много ячеек в файле')
    return wb
def preview(content):
    wb=workbook(content)
    return {'sheets':[{'name':s.title,'rows':s.max_row,'preview':[[str(c) if c is not None else '' for c in row] for row in s.iter_rows(max_row=min(s.max_row,12),values_only=True)]} for s in wb],'standard':'Structure' in wb.sheetnames and 'Materials' in wb.sheetnames}
def records(sheet,header_row=1):
    rows=list(sheet.iter_rows(values_only=True)); headers=[str(v).strip() if v is not None else '' for v in rows[header_row-1]]
    for rn,row in enumerate(rows[header_row:],header_row+1):
        if not any(v is not None for v in row): continue
        yield rn,{h:row[i] if i<len(row) else None for i,h in enumerate(headers) if h},headers
def import_standard(content,variant=None):
    wb=workbook(content); mats=[]; errors=[]; notices=[]; variants=[]
    if 'Materials' not in wb or 'Structure' not in wb: raise ValueError('Нужны листы Materials и Structure, либо сопоставьте столбцы')
    for rn,row,heads in records(wb['Materials']):
        cell=f'Materials!{rn}'; model=str(row.get('model') or 'constant'); mid=str(row.get('id') or '')
        def val(key,default=None): return row.get(key) if row.get(key) is not None else default
        try:
            if not mid: raise ValueError(f'{cell}: отсутствует id')
            if model=='library':
                m=load_material(str(val('dataset_id',''))); m.id=mid
            else:
                coeff=[float(x.strip().replace(',','.')) for x in str(val('coefficients','')).split(';') if x.strip()]
                n=number(row.get('n'),f'Materials!{get_column_letter(heads.index("n")+1)}{rn}') if model=='constant' else 1.5
                k=number(row.get('kappa'),f'Materials!{get_column_letter(heads.index("kappa")+1)}{rn}') if model=='constant' else number(val('kappa',0),cell)
                rng=None
                if val('range_min_um') is not None and val('range_max_um') is not None: rng=[number(val('range_min_um'),cell),number(val('range_max_um'),cell)]
                m=Material(id=mid,name=str(val('name',mid)),model=model,n=n,kappa=k,coefficients=coeff,range_um=rng,source={'description':str(val('source','Excel'))})
            m.transparent_approximation=str(val('transparent_approximation',False)).lower() in ['true','1','да']
            mats.append(m)
        except Exception as e: errors.append(f'{cell}: {e}')
    lookup={m.id:m for m in mats}
    if 'OpticalConstants' in wb:
        for rn,row,heads in records(wb['OpticalConstants']):
            try:
                mid=str(row.get('material_id')); unit=UNITS.get(str(row.get('unit','')).lower())
                if mid not in lookup: raise ValueError(f'неизвестный material_id {mid}')
                if not unit: raise ValueError('не указана единица длины волны')
                factor={'nm':1,'um':1000,'mm':1e6,'cm':1e7,'m':1e9}[unit]
                lookup[mid].table.append([number(row.get('wavelength'),f'OpticalConstants!B{rn}')*factor,number(row.get('n'),f'OpticalConstants!C{rn}'),number(row.get('kappa'),f'OpticalConstants!D{rn}')])
            except Exception as e: errors.append(f'OpticalConstants!{rn}: {e}')
    rows=list(records(wb['Structure']))
    variants=list(dict.fromkeys(str(row.get('variant') or 'default') for _,row,_ in rows))
    if len(variants)>1 and variant is None: return {'variants':variants,'needs_variant':True}
    variant=variant or (variants[0] if variants else 'default'); layers=[]; order=[]
    for rn,row,heads in rows:
        if str(row.get('variant') or 'default')!=variant: continue
        try:
            unit=UNITS.get(str(row.get('unit','')).lower())
            if not unit: raise ValueError(f'Structure!{get_column_letter(heads.index("unit")+1) if "unit" in heads else "E"}{rn}: укажите единицу толщины')
            value=number(row.get('thickness'),f'Structure!{get_column_letter(heads.index("thickness")+1)}{rn}')
            if value<0: raise ValueError(f'Structure!D{rn}: толщина не может быть отрицательной')
            order.append(number(row.get('order'),f'Structure!B{rn}'))
            layers.append(LayerInput(id=str(uuid.uuid4()),material_id=str(row.get('material_id')),thickness=value,unit=unit))
        except Exception as e: errors.append(str(e))
    if order!=list(range(1,len(order)+1)): errors.append('Structure!B: номера должны идти 1, 2, … от среды падения к подложке; строки автоматически не переставляются')
    settings={}
    if 'Settings' in wb:
        settings={str(row.get('parameter')):row.get('value') for _,row,_ in records(wb['Settings'])}
    allowed={'name','ambient_id','substrate_id','substrate_mode','kind','unit','start','stop','count','angles','refine'}
    for key in settings:
        if key not in allowed:errors.append(f'Settings:{key}: неподдерживаемый параметр. Конечная подложка и задняя поверхность не моделируются')
    if settings.get('substrate_mode','semi_infinite_lossless')!='semi_infinite_lossless':errors.append('Settings:substrate_mode: поддерживается только прозрачная полубесконечная подложка')
    required=['ambient_id','substrate_id','kind','unit','start','stop','count','angles']
    for key in required:
        if settings.get(key) is None: errors.append(f'Settings: отсутствует параметр {key}')
    if errors: raise ValueError('\n'.join(errors))
    plots=[]
    if 'Plots' in wb:
        for rn,row,_ in records(wb['Plots']): plots.append(PlotInput(id=str(row.get('id') or uuid.uuid4()),title=str(row.get('title') or 'Спектр'),quantities=[s.strip() for s in str(row.get('quantities') or 'Rs,Rp').split(',')],scale=str(row.get('scale') or 'linear')))
    angles=[number(a,'Settings:angles') for a in str(settings['angles']).split(';') if a.strip()]
    project=Project(name=str(settings.get('name') or 'Импорт Excel'),materials=mats,layers=layers,ambient_id=str(settings['ambient_id']),substrate_id=str(settings['substrate_id']),settings=Settings(kind=settings['kind'],unit=settings['unit'],start=number(settings['start'],'Settings:start'),stop=number(settings['stop'],'Settings:stop'),count=integer(settings['count'],'Settings:count'),angles=angles,refine=str(settings.get('refine',False)).lower()=='true'),**({'plots':plots} if plots else {}))
    return {'project':project.model_dump(),'notices':notices,'variants':variants}
def import_mapped(content,mapping,base):
    wb=workbook(content); name=mapping['sheet']; header=int(mapping.get('header_row',1)); unit=mapping.get('unit'); cols=mapping['columns']; layers=[]; p=Project.model_validate(base)
    if name not in wb: raise ValueError('Лист не найден')
    for rn,row,headers in records(wb[name],header):
        def value(key):
            col=cols.get(key); return row.get(col) if col else None
        def cell(key):
            col=cols.get(key); return f'{name}!{get_column_letter(headers.index(col)+1) if col in headers else "?"}{rn}'
        mid=str(value('material') or '')
        matches=[m for m in p.materials if m.id==mid or m.name==mid]
        if not matches:
            if value('n') is None: raise ValueError(f'{cell("material")}: неизвестный материал {mid}; сопоставьте столбцы n и κ или добавьте материал в проект')
            m=Material(id=f'import-{len(p.materials)}',name=mid or f'Материал {rn}',n=number(value('n'),cell('n')),kappa=number(value('kappa'),cell('kappa')))
            p.materials.append(m)
        else: m=matches[0]
        if matches and (cols.get('n') or cols.get('kappa')):
            if value('n') is None or value('kappa') is None:raise ValueError(f'{cell("n")} / {cell("kappa")}: при явном задании укажите оба n и κ')
            n=number(value('n'),cell('n'));kap=number(value('kappa'),cell('kappa'))
            if m.model!='constant' or m.n!=n or m.kappa!=kap:raise ValueError(f'{cell("n")} / {cell("kappa")}: n/κ конфликтуют с материалом «{mid}». Задайте отдельное имя или исправьте значения')
        u=UNITS.get(str(value('unit') or unit or '').lower())
        if not u: raise ValueError(f'{cell("thickness")}: укажите единицу толщины')
        layers.append(LayerInput(id=str(uuid.uuid4()),material_id=m.id,thickness=number(value('thickness'),cell('thickness')),unit=u))
    p.layers=layers; p=Project.model_validate(p.model_dump())
    return {'project':p.model_dump(),'notices':['Параметры диапазона, углов, среды и подложки сохранены из текущего проекта.']}
def export_results(calculations,format='xlsx'):
    allrows=[]
    for item in calculations:
        name=item.get('name','Расчёт'); calc=item.get('calculation',item)
        for spectrum in calc['spectra']:
            data=spectrum['data']; keys=list(data)
            for i in range(len(data['coordinate'])):
                row={'variant':name,'angle_deg':spectrum['angle']}
                for key in keys:
                    v=data[key][i]
                    if isinstance(v,dict): row[key+'_re']=v.get('re'); row[key+'_im']=v.get('im')
                    elif key in ['r_s','r_p','r_tan_s','r_tan_p','t_tan_s','t_tan_p','rho']: row[key+'_re']=None; row[key+'_im']=None
                    else: row[key]=v
                row['coordinate_unit']=spectrum['metadata']['coordinate_unit'];row['energy_unit']='fraction'; row['diagnostics']=json.dumps(spectrum['diagnostics'][i],ensure_ascii=False)
                allrows.append(row)
    if not allrows: raise ValueError('Нет результатов для экспорта')
    headers=list(allrows[0]);
    if format=='csv':
        out=io.StringIO(); writer=csv.DictWriter(out,fieldnames=headers);writer.writeheader();writer.writerows([{k:("'"+v if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')) else v) for k,v in row.items()} for row in allrows]);return out.getvalue().encode('utf-8-sig')
    wb=Workbook(); ws=wb.active;ws.title='Spectra';ws.append(headers)
    for row in allrows: ws.append([row.get(k) for k in headers])
    meta=wb.create_sheet('Metadata');meta.append(['variant','angle_deg','part','metadata_json'])
    for item in calculations:
        calc=item.get('calculation',item)
        for spectrum in calc['spectra']:
            txt=json.dumps(spectrum['metadata'],ensure_ascii=False)
            for i in range(0,len(txt),30000):meta.append([item.get('name','Расчёт'),spectrum['angle'],i//30000+1,txt[i:i+30000]])
    project=wb.create_sheet('Projects');project.append(['variant','part','project_json'])
    for item in calculations:
        txt=json.dumps(item.get('calculation',item)['project'],ensure_ascii=False)
        for i in range(0,len(txt),30000):project.append([item.get('name','Расчёт'),i//30000+1,txt[i:i+30000]])
    for sheet in wb:
        for row in sheet:
            for cell in row:
                if isinstance(cell.value,str):cell.data_type='s'
        sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
        for cell in sheet[1]:cell.fill=PatternFill('solid',fgColor='2468EF');cell.font=Font(color='FFFFFF',bold=True)
        for i in range(1,sheet.max_column+1):sheet.column_dimensions[get_column_letter(i)].width=21
    out=io.BytesIO();wb.save(out);return out.getvalue()
