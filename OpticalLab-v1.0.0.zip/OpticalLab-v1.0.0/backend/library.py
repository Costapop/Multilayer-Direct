"""Versioned, cached refractiveindex.info reader. Only public database URLs."""
from pathlib import Path
from urllib.parse import quote
import json, hashlib, re
import httpx, yaml
from .models import Material
CACHE=Path(__file__).parent.parent/'.runtime'/'materials'
REPO='polyanskiy/refractiveindex.info-database'
CURATED=[('SiO2','Плавленый кварц · Malitson 1965','main/SiO2/nk/Malitson.yml'),('TiO2','Плёнка · Sarkar 2019','main/TiO2/nk/Sarkar.yml'),('Ta2O5','Аморфная плёнка · Gao 2012','main/Ta2O5/nk/Gao.yml'),('MgF2','Плёнка · Rodríguez-de Marcos 2017','main/MgF2/nk/Rodriguez-de Marcos.yml'),('Al2O3','Аморфная плёнка · Boidin 2016','main/Al2O3/nk/Boidin.yml'),('Ag','Johnson & Christy 1972','main/Ag/nk/Johnson.yml'),('Au','Johnson & Christy 1972','main/Au/nk/Johnson.yml'),('N-BK7','SCHOTT · стекло','specs/schott/optical/N-BK7.yml')]
def fetch(url):
    r=httpx.get(url,timeout=30,follow_redirects=True); r.raise_for_status(); return r.text
def version():
    CACHE.mkdir(parents=True,exist_ok=True); path=CACHE/'version.txt'
    if path.exists(): return path.read_text().strip()
    data=json.loads(fetch(f'https://api.github.com/repos/{REPO}/commits/main'))
    sha=data['sha']; path.write_text(sha); return sha
def cached_file(path):
    if not re.fullmatch(r'[A-Za-z0-9 _./+()\-]+\.yml',path) or '..' in path: raise ValueError('Некорректный путь набора данных')
    sha=version(); target=CACHE/sha/path
    url=f'https://raw.githubusercontent.com/{REPO}/{sha}/database/{quote(path)}'
    if not target.exists(): target.parent.mkdir(parents=True,exist_ok=True); target.write_text(fetch(url))
    return target.read_text(),sha,url
def search(query=''):
    try:
        raw,sha,_=cached_file('catalog-nk.yml'); tree=yaml.safe_load(raw); rows=[]
        def walk(items,book=''):
            for item in items:
                if not isinstance(item,dict): continue
                label=item.get('name',item.get('BOOK',book))
                if 'BOOK' in item: book2=item.get('BOOK','')+' · '+str(label)
                else: book2=book
                if 'data' in item: rows.append({'material':book,'label':str(item.get('name',item.get('PAGE',''))),'path':item['data'],'version':sha})
                if isinstance(item.get('content'),list): walk(item['content'],book2)
        walk(tree)
        q=query.casefold().strip()
        if q: rows=[r for r in rows if q in (r['material']+' '+r['label']+' '+r['path']).casefold()]
        else:
            paths={p for _,_,p in CURATED}; rows=[r for r in rows if r['path'] in paths]
        return rows[:80]
    except Exception:
        return [{'material':m,'label':l,'path':p,'version':'при загрузке'} for m,l,p in CURATED if query.casefold() in (m+' '+l).casefold()]
def load_material(path):
    if re.search(r'-(?:o|e)(?:[-.]|$)',path.rsplit('/',1)[-1]):raise ValueError('Этот набор описывает отдельную ось анизотропного материала. Скалярное ядро его не поддерживает; выберите изотропную плёнку')
    raw,sha,url=cached_file('data/'+path); data=yaml.safe_load(raw); components=[]; ranges=[]
    for part in data.get('DATA',[]):
        typ=part.get('type','')
        if typ.startswith('formula'):
            component={'type':typ,'coefficients':[float(c) for c in str(part['coefficients']).split()],'range_um':[float(v) for v in part['wavelength_range'].split()]}
            ranges.append(component['range_um'])
        elif typ in ['tabulated n','tabulated k','tabulated nk']:
            rows=[[float(v) for v in line.split()] for line in part['data'].splitlines() if line.strip()]
            component={'type':typ,'values':rows}; ranges.append([rows[0][0],rows[-1][0]])
        else: raise ValueError(f'Неподдерживаемый формат {typ}')
        components.append(component)
    if not ranges: raise ValueError('В наборе отсутствуют оптические константы')
    title=path.split('/')[-1].replace('.yml',''); material=path.split('/')[1]
    return Material(id='rii-'+hashlib.sha256(path.encode()).hexdigest()[:10],name=f'{material} · {title}',model='library',range_um=[max(r[0] for r in ranges),min(r[1] for r in ranges)],components=components,source={'library':'refractiveindex.info','dataset':path,'version':sha,'url':url,'references':data.get('REFERENCES',''),'comments':data.get('COMMENTS',''),'specs':data.get('SPECS',{}),'conditions':data.get('CONDITIONS',{}),'properties':data.get('PROPERTIES',{}),'license':'CC0-1.0','has_kappa':any(c['type'] in ['tabulated k','tabulated nk'] for c in components)})
