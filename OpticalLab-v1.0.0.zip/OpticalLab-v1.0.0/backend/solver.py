from __future__ import annotations
import sys, math
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).parent/'vendor'))
from multilayer_optics import Layer, TabulatedMaterial, SpectrumResult, stream_spectrum, refine_spectrum, make_grid, to_k, evaluate_index
from .models import Project, Material
CORE_COMMIT='282569961aeaa70506e356f68c9068ea267903fc'
def bounded(x,lower,upper,label):
    x=np.asarray(x,dtype=float)
    tolerance=8*np.finfo(float).eps*max(abs(lower),abs(upper))
    if x.min()<lower-tolerance or x.max()>upper+tolerance:raise ValueError(f'{label}: допустимый диапазон {lower:g}–{upper:g} мкм')
    return np.clip(x,lower,upper)

def component_values(part, wavelength_um):
    kind=part['type']; x=np.asarray(wavelength_um)
    if kind.startswith('tabulated'):
        table=np.asarray(part['values'],float)
        expected=3 if kind=='tabulated nk' else 2
        if table.ndim!=2 or table.shape[1]!=expected or len(table)<2 or not np.all(np.isfinite(table)):raise ValueError('Некорректная таблица материала: проверьте строки, столбцы и конечность значений')
        if np.any(np.diff(table[:,0])<=0) or np.any(table[:,0]<=0) or np.any(table[:,1:]<0): raise ValueError('Таблица: λ строго возрастает и положительна; n и κ неотрицательны')
        x=bounded(x,table[0,0],table[-1,0],'Таблица')
        return [np.interp(x,table[:,0],table[:,i]) for i in range(1,table.shape[1])]
    lower,upper=part['range_um']
    x=bounded(x,lower,upper,'Формула')
    c=part['coefficients']; typ=int(kind.split()[-1]); xx=x*x
    with np.errstate(all='raise'):
        if typ in (1,2):
            z=np.full_like(x,1+c[0])
            for i in range(1,len(c),2): z+=c[i]*xx/(xx-(c[i+1]**2 if typ==1 else c[i+1]))
            if np.any(z<0): raise ValueError('Формула даёт отрицательное n²')
            return [np.sqrt(z)]
        if typ in (3,5):
            z=np.full_like(x,c[0])
            for i in range(1,len(c),2): z+=c[i]*x**c[i+1]
            if typ==3:
                if np.any(z<0): raise ValueError('Формула даёт отрицательное n²')
                z=np.sqrt(z)
            return [z]
    raise ValueError(f'Тип дисперсии {kind} не поддерживается; выберите табличный набор')

def material_function(m: Material, transparent=False):
    if m.model=='library':
        channels=[]
        for part in m.components:
            typ=part.get('type','')
            if typ.startswith('tabulated'):
                a=np.asarray(part.get('values',[]),float);expected=3 if typ=='tabulated nk' else 2
                if a.ndim!=2 or a.shape[1]!=expected or len(a)<2 or not np.all(np.isfinite(a)) or np.any(a[:,0]<=0) or np.any(np.diff(a[:,0])<=0) or np.any(a[:,1:]<0):raise ValueError(f'{m.name}: некорректная исходная таблица n/κ')
                channels.extend(['n','k'] if typ=='tabulated nk' else ['k'] if typ=='tabulated k' else ['n'])
            elif typ.startswith('formula'):
                c=np.asarray(part.get('coefficients',[]),float);r=part.get('range_um',[])
                if len(c)<1 or len(c)%2!=1 or not np.all(np.isfinite(c)) or len(r)!=2 or not 0<r[0]<r[1]:raise ValueError(f'{m.name}: некорректные коэффициенты или диапазон формулы')
                channels.append('n')
            else:raise ValueError(f'Неподдерживаемый формат {typ}')
        if len(channels)!=len(set(channels)):raise ValueError(f'{m.name}: конфликтующие компоненты n или κ')
    if m.model=='constant':
        if transparent and m.kappa != 0: raise ValueError(f'{m.name}: подложка и среда падения должны быть непоглощающими')
        return complex(m.n,-m.kappa)
    if m.model=='tabulated':
        a=np.array(m.table,float)
        if a.ndim!=2 or a.shape[1]!=3 or len(a)<2: raise ValueError(f'{m.name}: таблица требует λ [нм], n, κ и минимум 2 строки')
        if not np.all(np.isfinite(a)) or np.any(a[:,0]<=0) or np.any(np.diff(a[:,0])<=0) or np.any(a[:,1:]<0):raise ValueError(f'{m.name}: некорректная исходная таблица n/κ')
        if transparent and np.any(a[:,2]!=0) and not m.transparent_approximation: raise ValueError(f'{m.name}: таблица содержит поглощение; прозрачное приближение не выбрано')
        vals=a[:,1]-1j*(np.zeros(len(a)) if m.transparent_approximation else a[:,2])
        return TabulatedMaterial(a[:,0],vals,kind='wavelength',unit='nm')
    if transparent and m.model=='library' and not m.transparent_approximation:
        for part in m.components:
            if part['type'] in ['tabulated k','tabulated nk'] and any(row[-1]!=0 for row in part['values']): raise ValueError(f'{m.name}: исходная таблица содержит κ ≠ 0; подложка должна быть прозрачной')
    def fn(k):
        wl=2*np.pi/np.asarray(k)
        if m.range_um:wl=bounded(wl,m.range_um[0],m.range_um[1],m.name)
        if m.model=='cauchy':
            if len(m.coefficients)!=3: raise ValueError(f'{m.name}: Коши требует A, B [мкм²], C [мкм⁴]')
            a,b,c=m.coefficients; n=a+b/wl**2+c/wl**4; kap=np.full_like(wl,m.kappa)
        elif m.model=='sellmeier':
            if len(m.coefficients)!=6: raise ValueError(f'{m.name}: Зельмейер требует B1,C1,B2,C2,B3,C3; C в мкм²')
            n=component_values({'type':'formula 2','coefficients':[0]+m.coefficients,'range_um':m.range_um or [0,float('inf')]},wl)[0]; kap=np.full_like(wl,m.kappa)
        else:
            n=None; kap=None
            for part in m.components:
                values=component_values(part,wl)
                if part['type']=='tabulated nk': n,kap=values
                elif part['type']=='tabulated k': kap=values[0]
                else: n=values[0]
            if n is None: raise ValueError(f'{m.name}: отсутствуют данные n')
            if kap is None:
                if not m.transparent_approximation: raise ValueError(f'{m.name}: κ отсутствует. Явно выберите прозрачное приближение либо другой набор')
                kap=np.zeros_like(wl)
        if m.transparent_approximation: kap=np.zeros_like(wl)
        if transparent and np.any(kap!=0): raise ValueError(f'{m.name}: подложка/среда поглощает. Поддерживается только прозрачная среда')
        if np.any(n<0) or np.any(kap<0) or not np.all(np.isfinite(n+kap)): raise ValueError(f'{m.name}: некорректные n или κ')
        return n-1j*kap
    return fn

def prepare(project: Project):
    s=project.settings; grid=make_grid(s.start,s.stop,s.count); k=to_k(grid,s.kind,s.unit)
    mats={m.id:m for m in project.materials}; ambient=material_function(mats[project.ambient_id],True); substrate=material_function(mats[project.substrate_id],True)
    evaluate_index(ambient,k,transparent=True); evaluate_index(substrate,k,transparent=True)
    layers=[]
    for inp in project.layers:
        f=material_function(mats[inp.material_id]); evaluate_index(f,k)
        layers.append(Layer(f,inp.thickness,inp.unit,name=inp.name or mats[inp.material_id].name))
    return grid,layers,ambient,substrate

def calculate(project: Project, progress=lambda v:None, cancelled=lambda:False):
    grid,layers,ambient,substrate=prepare(project); s=project.settings; spectra=[]
    original_ambient=ambient
    def checked_ambient(k):
        if cancelled():raise InterruptedError('Расчёт отменён')
        return evaluate_index(original_ambient,k,transparent=True)
    ambient=checked_ambient
    for ai,angle in enumerate(s.angles):
        points=[]
        for i,p in enumerate(stream_spectrum(grid,layers,substrate,angle,ambient=ambient,kind=s.kind,unit=s.unit)):
            if cancelled(): raise InterruptedError('Расчёт отменён')
            points.append(p)
            if i%16==0: progress((ai+(i+1)/len(grid))/len(s.angles)*.9)
        metadata={'core_commit':CORE_COMMIT,'angle_deg':angle,'coordinate_kind':s.kind,'coordinate_unit':s.unit,'time_convention':'exp(+iwt)','index_convention':'n_minus_ik','layer_order':'ambient_to_substrate','substrate':'semi_infinite_lossless','r_p_definition':'minus tangential electric reflection','rho_definition':'r_p/r_s','energy_unit':'fraction','log_T_base':'e','precision':'float64/complex128','material_sources':[m.model_dump() for m in project.materials]}
        result=SpectrumResult(grid,tuple(points),metadata)
        if s.refine:
            if cancelled(): raise InterruptedError('Расчёт отменён')
            budget=int(6_000_000/(max(1,len(layers))*len(s.angles)))
            r=refine_spectrum(grid,layers,substrate,angle,ambient=ambient,kind=s.kind,unit=s.unit,max_rounds=3,max_points=min(20001,budget,max(1601,len(grid)*4-3)))
            result=r.spectrum; metadata.update(result.metadata)
            metadata['refinement']={'converged':r.converged,'reason':r.reason,'rounds':r.rounds,'normalized_error':r.normalized_error if math.isfinite(r.normalized_error) else None,'note':'Критерий середин не гарантирует обнаружение всех узких резонансов'}
        obj=result.to_dict(); obj['metadata'].update(metadata); data=obj['data']
        for q in ['R','T','A']: data[q]=[(a+b)/2 if a is not None and b is not None else None for a,b in zip(data[q+'s'],data[q+'p'])]
        spectra.append({'angle':angle,**obj})
    progress(1)
    return {'project':project.model_dump(),'spectra':spectra,'core_commit':CORE_COMMIT}
