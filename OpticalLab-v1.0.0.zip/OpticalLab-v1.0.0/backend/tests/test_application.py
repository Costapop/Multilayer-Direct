import copy, io, json, math, time, unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from openpyxl import load_workbook, Workbook
from fastapi.testclient import TestClient
from pydantic import ValidationError
from backend.models import Project,Material,LayerInput,demo_project
from backend.solver import calculate,prepare,material_function,component_values
from backend.excel_io import import_standard,import_mapped,export_results
from backend.app import app
from backend import agent

ROOT=Path(__file__).resolve().parents[2]
class ApplicationTests(unittest.TestCase):
    def bare(self,n0=1,ns=1.5,angle=0):
        p=demo_project();p.layers=[];p.materials[0].n=n0;p.materials[1].n=ns;p.settings.start=500;p.settings.stop=600;p.settings.count=2;p.settings.angles=[angle];return p
    def fixture(self,d=120):
        p=self.bare(angle=53);p.materials.append(Material(id='film',name='film',n=1.8,kappa=.03));p.layers=[LayerInput(id='f',material_id='film',thickness=d)];return p
    def workbook_bytes(self,mutate=lambda wb:None):
        wb=load_workbook(ROOT/'public/coating-template.xlsx');mutate(wb);out=io.BytesIO();wb.save(out);return out.getvalue()
    def test_fresnel_energy_and_basis(self):
        d=calculate(self.bare())['spectra'][0]['data']
        for key,value in [('Rs',.04),('Rp',.04),('Ts',.96),('Tp',.96),('psi_deg',45),('delta_deg',180)]:np.testing.assert_allclose(d[key],value,atol=1e-12)
        self.assertAlmostEqual(d['rho'][0]['re'],-1)
    def test_absorbing_fixture_and_units(self):
        expected=[.20335928542802764,.2622034136943332]
        for unit,factor in [('nm',1),('um',1e-3),('mm',1e-6),('cm',1e-7),('m',1e-9)]:
            p=self.fixture();p.layers[0].thickness=120*factor;p.layers[0].unit=unit
            np.testing.assert_allclose(calculate(p)['spectra'][0]['data']['Rs'],expected,atol=1e-12)
    def test_masks_strict_json_and_brewster(self):
        r=calculate(self.bare(ns=1));json.dumps(r,allow_nan=False);d=r['spectra'][0]['data'];self.assertIsNone(d['delta_deg'][0]);self.assertFalse(d['delta_valid'][0]);self.assertTrue(d['valid_s'][0])
        d=calculate(self.bare(angle=math.degrees(math.atan(1.5))))['spectra'][0]['data'];self.assertTrue(d['psi_valid'][0]);self.assertFalse(d['delta_valid'][0])
    def test_underflow_and_physical_zero(self):
        p=self.bare(n0=1.5,ns=1,angle=60);d=calculate(p)['spectra'][0]['data'];self.assertEqual(d['transmission_status_s'][0],'zero_normal_flux');self.assertIsNone(d['log_T_s'][0])
        p=self.bare(angle=60);p.materials.append(Material(id='f',name='f',n=1.5,kappa=.5));p.layers=[LayerInput(id='f',material_id='f',thickness=1000,unit='um')];d=calculate(p)['spectra'][0]['data'];self.assertEqual(d['transmission_status_s'][0],'power_underflow');self.assertLess(d['log_T_s'][0],-10000)
    def test_partial_enz(self):
        p=self.bare(angle=30);p.materials.append(Material(id='f',name='f',n=0));p.layers=[LayerInput(id='f',material_id='f',thickness=100)];d=calculate(p)['spectra'][0]['data'];self.assertTrue(d['valid_s'][0]);self.assertFalse(d['valid_p'][0]);self.assertIsNone(d['Rp'][0])
    def test_unsupported_and_boolean(self):
        p=self.bare().model_dump();p['substrate_mode']='finite'
        with self.assertRaises(ValidationError):Project.model_validate(p)
        with self.assertRaises(ValidationError):LayerInput(id='x',material_id='H',thickness=True)
        p=self.bare();p.materials[1].kappa=1e-15
        with self.assertRaises(ValueError):prepare(p)
    def test_table_interpolation_and_validation(self):
        m=Material(id='t',name='t',model='tabulated',table=[[400,1.4,.01],[800,1.8,.05]])
        f=material_function(m);self.assertAlmostEqual(f(2*np.pi/np.array([.6]))[0],1.6-.03j)
        with self.assertRaises(ValueError):f(2*np.pi/np.array([.399]))
        m.table[0][2]=-.01;m.transparent_approximation=True
        with self.assertRaises(ValueError):material_function(m)
    def test_range_roundtrip(self):
        p=self.bare();p.settings.start=400;p.settings.stop=800;p.materials[1]=Material(id='glass',name='Cauchy',model='cauchy',coefficients=[1.5,0,0],range_um=[.4,.8]);prepare(p)
        p.settings.start=399.99
        with self.assertRaises(ValueError):prepare(p)
    def test_formula_types(self):
        p={'type':'formula 1','coefficients':[0,1,.1],'range_um':[.2,2]};a=component_values(p,np.array([.6]))[0]
        p.update(type='formula 2',coefficients=[0,1,.01]);np.testing.assert_allclose(component_values(p,np.array([.6]))[0],a)
    def test_excel_roundtrip(self):
        parsed=Project.model_validate(import_standard((ROOT/'public/coating-template.xlsx').read_bytes())['project']);ref=calculate(demo_project())['spectra'][0]['data'];got=calculate(parsed)['spectra'][0]['data']
        for key in ['Rs','Rp','Ts','Tp']:np.testing.assert_allclose(got[key],ref[key],atol=1e-12)
    def test_excel_decimal_angles_and_integer(self):
        def change(wb):
            for row in wb['Settings']:
                if row[0].value=='angles':row[1].value='30,5;45,5'
        p=import_standard(self.workbook_bytes(change))['project'];self.assertEqual(p['settings']['angles'],[30.5,45.5])
        def bad(wb):
            for row in wb['Settings']:
                if row[0].value=='count':row[1].value=2.9
        with self.assertRaisesRegex(ValueError,'целое'):import_standard(self.workbook_bytes(bad))
    def test_excel_finite_and_cell_error(self):
        with self.assertRaisesRegex(ValueError,'неподдерживаемый'):import_standard(self.workbook_bytes(lambda w:w['Settings'].append(['substrate_thickness',1,'mm'])))
        with self.assertRaisesRegex(ValueError,'Structure!E2'):import_standard(self.workbook_bytes(lambda w:setattr(w['Structure']['E2'],'value',None)))
    def test_mapping_conflict(self):
        wb=Workbook();ws=wb.active;ws.title='Layers';ws.append(['material','n','kappa','thickness']);ws.append(['H',1.2,.05,100]);o=io.BytesIO();wb.save(o)
        with self.assertRaisesRegex(ValueError,'конфликт'):import_mapped(o.getvalue(),{'sheet':'Layers','unit':'nm','columns':{'material':'material','n':'n','kappa':'kappa','thickness':'thickness'}},demo_project().model_dump())
    def test_long_export_project_recovery(self):
        p=self.fixture();p.materials.append(Material(id='table',name='unused table',model='tabulated',table=[[300+i,1.5,0] for i in range(2000)]));r=calculate(p);buf=export_results([{'name':'=1+1','calculation':r}]);wb=load_workbook(io.BytesIO(buf),data_only=True);joined=''.join(row[2] for row in list(wb['Projects'].values)[1:]);self.assertEqual(json.loads(joined),p.model_dump());self.assertGreater(len(joined),32767);self.assertEqual(wb['Spectra']['A2'].value,'=1+1')
    def test_saved_project_reproducibility(self):
        p=self.fixture();a=calculate(p);p.layers[0].thickness=130;b=calculate(p);self.assertEqual(a['project']['layers'][0]['thickness'],120)
        np.testing.assert_allclose(b['spectra'][0]['data']['Rs'],[.17274469581708238,.2398105632146656],atol=1e-12)
        restored=calculate(Project.model_validate(json.loads(json.dumps(a))['project']));self.assertEqual(a['spectra'][0]['data'],restored['spectra'][0]['data'])
    def test_job_session_and_validation(self):
        c=TestClient(app);h=c.get('/health');self.assertEqual(h.status_code,200);r=c.post('/validate',json=self.bare().model_dump());self.assertIn('project',r.json())
        jid=c.post('/jobs',json=self.bare().model_dump()).json()['id'];self.assertEqual(TestClient(app).get('/jobs/'+jid).status_code,404)
        for _ in range(100):
            r=c.get('/jobs/'+jid).json()
            if r['status']=='done':break
            time.sleep(.01)
        self.assertEqual(r['status'],'done');self.assertEqual(len(r['result']['spectra']),1)
    def test_agent_not_configured(self):
        with patch.dict('os.environ',{},clear=True):
            with self.assertRaisesRegex(ValueError,'Подключите'):agent.chat('test',[],demo_project(),{})
    def test_session_disconnect_and_local_origin(self):
        c=TestClient(app)
        with patch.dict('os.environ',{'OPENAI_API_KEY':'server-test'}):
            self.assertTrue(c.get('/health').json()['ai_connected'])
            self.assertFalse(c.post('/config',json={'disconnect':True}).json()['connected'])
            self.assertFalse(c.get('/health').json()['ai_connected'])
            self.assertEqual(c.post('/chat',json={'message':'test','project':self.bare().model_dump()}).status_code,422)
        self.assertEqual(c.get('/health',headers={'host':'attacker.example'}).status_code,403)
        self.assertEqual(c.post('/config',json={},headers={'origin':'https://attacker.example'}).status_code,403)
    def test_agent_partial_response_and_preserve_calculation(self):
        p=self.bare();first=p.model_dump();second=p.model_dump();second['plots'][0]['title']='Новое название'
        def tool_call(value,compute):return {'output':[{'type':'function_call','name':'update_project','call_id':'1','arguments':json.dumps({'project_json':json.dumps(value),'summary':'Изменено','calculate':compute,'save_previous':False})}]}
        class Response:
            is_success=True
            def __init__(self,data):self.data=data
            def json(self):return self.data
        with patch.object(agent.httpx.Client,'post',side_effect=[Response(tool_call(first,True)),Response(tool_call(second,False)),Response({'output':[{'type':'message','content':[{'type':'output_text','text':'Готово'}]}]})]):
            out=agent.chat('test',[],p,{'key':'test'})
        self.assertIsNotNone(out['calculation']);self.assertEqual(out['calculation']['project']['plots'][0]['title'],'Новое название')
        with patch.object(agent.httpx.Client,'post',return_value=Response({'status':'incomplete','incomplete_details':{'reason':'max_output_tokens'},'output':[]})):
            with self.assertRaisesRegex(ValueError,'не завершён'):agent.chat('test',[],p,{'key':'test'})
    def test_agent_tool_integration(self):
        project=self.bare(); changed=project.model_dump();changed['settings']['angles']=[45]
        outputs=[{'output':[{'type':'function_call','name':'update_project','call_id':'1','arguments':json.dumps({'project_json':json.dumps(changed),'summary':'Угол 45°','calculate':True,'save_previous':True})}]},{'output':[{'type':'message','content':[{'type':'output_text','text':'Рассчитано при 45°.'}]}]}]
        class MockResponse:
            is_success=True
            def __init__(self,data):self.data=data
            def json(self):return self.data
        class MockClient:
            def __init__(self,**kw):pass
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def post(self,*args,**kw):return MockResponse(outputs.pop(0))
        with patch.object(agent.httpx,'Client',MockClient):out=agent.chat('45°',[],project,{'key':'test-key','model':'test-model'})
        self.assertTrue(out['save_previous']);self.assertEqual(out['calculation']['spectra'][0]['angle'],45);self.assertAlmostEqual(out['calculation']['spectra'][0]['data']['Rs'][0],.0920133630455244)

if __name__=='__main__':unittest.main()
