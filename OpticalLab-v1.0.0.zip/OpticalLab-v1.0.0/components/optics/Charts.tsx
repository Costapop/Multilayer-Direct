'use client';
import {useMemo,useState,useRef} from 'react';
import {ResponsiveContainer,LineChart,Line,XAxis,YAxis,CartesianGrid,Tooltip,ReferenceArea} from 'recharts';
import {RotateCcw,Download,Settings2,ChevronLeft,ChevronRight,Trash2} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';
import {Checkbox} from '@/components/ui/checkbox';
import {Input} from '@/components/ui/input';
import Choice from './Choice';
import {Snapshot,PlotConfig,Spectrum,quantities,colors,energy,download} from '@/lib/optics';
function getValue(s:Spectrum,q:string,i:number,unwrapped:boolean,percent:boolean,log:boolean){
 let v:any=s.data[q]?.[i];
 if(q==='delta_deg'&&unwrapped){const raw=s.data.delta_unwrapped_rad?.[i];v=raw==null?null:raw*180/Math.PI;}
 if(q.endsWith('_abs')||q.endsWith('_re')||q.endsWith('_im')||q.endsWith('_arg')){const tail=q.split('_').pop()!;const z=s.data[q.slice(0,-tail.length-1)]?.[i];v=z==null?null:tail==='abs'?Math.hypot(z.re,z.im):tail==='arg'?(z.re===0&&z.im===0?null:Math.atan2(z.im,z.re)*180/Math.PI):z[tail];}
 if(q==='rho_arg'&&s.data.delta_valid?.[i]===false)return null;
 if((q==='r_s_arg'||q==='r_p_arg')&&Math.hypot(s.data[q.slice(0,-4)]?.[i]?.re||0,s.data[q.slice(0,-4)]?.[i]?.im||0)<=1e-12)return null;
 if(v==null||typeof v!=='number'||!Number.isFinite(v))return null;
 if(q.startsWith('phase_t_'))v=v*180/Math.PI;
 const pol=/[sp]$/.test(q)?q.slice(-1):null;
 if(energy(q)&&pol&&s.data['valid_'+pol]?.[i]===false)return null;
 if(log&&/^T[sp]$/.test(q)){const lt=s.data['log_T_'+pol]?.[i];return lt==null?null:lt/Math.LN10+(percent?2:0);}
 if(energy(q)&&percent)v*=100;
 return log?(v>0?Math.log10(v):null):v;
}
const quantityGroup=(q:string)=>energy(q)?'energy':q.includes('deg')||q.startsWith('phase_')||q.endsWith('_arg')?'angle':'amplitude';
export default function Chart({plot,onChange,onRemove,snapshots,percent,axis,domain,setDomain}:{plot:PlotConfig;onChange:(v:PlotConfig)=>void;onRemove:()=>void;snapshots:Snapshot[];percent:boolean;axis:string;domain:[number,number]|null;setDomain:(d:[number,number]|null)=>void}){
 const [hidden,setHidden]=useState<string[]>([]),[config,setConfig]=useState(false),[left,setLeft]=useState<number|null>(null),[right,setRight]=useState<number|null>(null);const root=useRef<HTMLDivElement>(null);
 const series=useMemo(()=>snapshots.filter(s=>s.visible).flatMap((snap,si)=>snap.calculation.spectra.flatMap((s,ai)=>plot.quantities.map((q,qi)=>{
   const id=`${snap.id}-${s.angle}-${q}`;let prev:number|null=null;
   const data=s.data.lambda_um.map((wl,i)=>{let y=getValue(s,q,i,plot.unwrapped,percent,plot.scale==='log');if(((q==='delta_deg'&&!plot.unwrapped)||q.endsWith('_arg')||q.startsWith('phase_t_'))&&y!=null&&prev!=null&&Math.abs(y-prev)>180){prev=y;y=null;}else if(y!=null)prev=y;return {x:axis==='nm'?wl*1000:axis==='um'?wl:axis==='cm^-1'?10000/wl:2*Math.PI/wl,y};}).sort((a,b)=>a.x-b.x);
   return {id,name:`${quantities[q]||q} · ${s.angle}° · ${snap.name}`,data,color:si===0?colors[(qi+ai*2)%colors.length]:snap.color,dash:[undefined,'7 3','2 3','9 3 2 3','12 4','3 3 3 6'][(qi+ai*plot.quantities.length)%6]};
 }))),[snapshots,plot,percent,axis]);
 const ends=series.flatMap(s=>s.data.length?[s.data[0].x,s.data[s.data.length-1].x]:[]);const full:[number,number]=ends.length?[Math.min(...ends),Math.max(...ends)]:[400,800];const xd=domain||full;
 const unit=plot.quantities.every(energy)?(percent?'%':'доли'):plot.quantities.some(q=>q.includes('deg')||q.startsWith('phase_')||q.endsWith('_arg'))?'°':'амплитуда';
 function zoom(){if(left!=null&&right!=null&&left!==right)setDomain([Math.min(left,right),Math.max(left,right)]);setLeft(null);setRight(null);}
 async function exportImage(fmt:'svg'|'png'){
  const source=root.current?.querySelector('svg.recharts-surface');if(!source)return;
  const svg=source.cloneNode(true) as SVGElement;svg.setAttribute('xmlns','http://www.w3.org/2000/svg');const box=source.getBoundingClientRect();
  const visible=series.filter(s=>!hidden.includes(s.id));const chars=Math.max(20,Math.floor((box.width-60)/6));let row=0;
  const addText=(text:string,x:number,y:number,size:number)=>{const el=document.createElementNS('http://www.w3.org/2000/svg','text');el.setAttribute('x',String(x));el.setAttribute('y',String(y));el.setAttribute('font-size',String(size));el.setAttribute('font-family','Arial, sans-serif');el.setAttribute('fill','#172339');el.textContent=text;svg.appendChild(el);};
  addText(`${plot.title} · ${plot.scale==='log'?'log10 ':''}${unit} · ${axis}`,10,-14,14);
  visible.forEach(s=>{const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.setAttribute('x1','10');line.setAttribute('x2','32');line.setAttribute('y1',String(box.height+14+row*16));line.setAttribute('y2',String(box.height+14+row*16));line.setAttribute('stroke',s.color);line.setAttribute('stroke-width','2');if(s.dash)line.setAttribute('stroke-dasharray',s.dash);svg.appendChild(line);for(let i=0;i<s.name.length;i+=chars){addText(s.name.slice(i,i+chars),40,box.height+18+row*16,10);row++;}});
  const exportHeight=box.height+52+row*16;svg.setAttribute('width',String(box.width));svg.setAttribute('height',String(exportHeight));svg.setAttribute('viewBox',`0 -34 ${box.width} ${exportHeight}`);
  const data=new XMLSerializer().serializeToString(svg);
  if(fmt==='svg'){download(data,plot.title+'.svg','image/svg+xml');return;}
  const url=URL.createObjectURL(new Blob([data],{type:'image/svg+xml'}));const img=new Image();img.onload=()=>{const c=document.createElement('canvas');c.width=box.width*2;c.height=exportHeight*2;const ctx=c.getContext('2d')!;ctx.fillStyle='white';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(img,0,0,c.width,c.height);c.toBlob(b=>{if(b)download(b,plot.title+'.png','image/png');});URL.revokeObjectURL(url);};img.src=url;
 }
 return <div className="plot-card" ref={root}><div className="plot-heading"><h2>{plot.title}<span className="plot-unit">{plot.scale==='log'?'log₁₀ · ':''}{unit}</span></h2><div className="chart-actions"><Button variant="ghost" size="icon" title="Сдвинуть диапазон влево" aria-label="Сдвинуть диапазон влево" onClick={()=>setDomain([xd[0]-(xd[1]-xd[0])*.2,xd[1]-(xd[1]-xd[0])*.2])}><ChevronLeft/></Button><Button variant="ghost" size="icon" title="Сдвинуть диапазон вправо" aria-label="Сдвинуть диапазон вправо" onClick={()=>setDomain([xd[0]+(xd[1]-xd[0])*.2,xd[1]+(xd[1]-xd[0])*.2])}><ChevronRight/></Button><Button variant="ghost" size="icon" title="Сбросить масштаб" aria-label="Сбросить масштаб" onClick={()=>setDomain(null)}><RotateCcw/></Button><Button variant="ghost" size="icon" aria-label={`Настроить ${plot.title}`} onClick={()=>setConfig(true)}><Settings2/></Button></div></div>
 <div className="chart-space">{series.length?<ResponsiveContainer width="100%" height="100%"><LineChart data={series[0].data} syncId="spectra" syncMethod="value" margin={{top:8,right:10,left:-15,bottom:2}} onMouseDown={(e:any)=>{if(e.activeLabel!=null)setLeft(Number(e.activeLabel));}} onMouseMove={(e:any)=>{if(left!=null&&e.activeLabel!=null)setRight(Number(e.activeLabel));}} onMouseUp={zoom}><CartesianGrid vertical={false} stroke="#e8edf4"/><XAxis dataKey="x" type="number" domain={xd} allowDataOverflow tick={{fontSize:12,fill:'#718098'}} tickFormatter={n=>Number(n).toLocaleString('ru-RU',{maximumSignificantDigits:4})} tickLine={false} axisLine={false}/><YAxis domain={['auto','auto']} tick={{fontSize:12,fill:'#718098'}} tickFormatter={n=>Number(n).toPrecision(3)} tickLine={false} axisLine={false}/><Tooltip labelFormatter={x=>`${Number(x).toFixed(3)} ${axis}`} formatter={(v,name)=>[v==null?'не определено':Number(v).toPrecision(6),name]}/>{series.filter(s=>!hidden.includes(s.id)).map(s=><Line key={s.id} data={s.data} dataKey="y" name={s.name} stroke={s.color} strokeDasharray={s.dash} strokeWidth={2} dot={false} connectNulls={false} isAnimationActive={false} type="linear"/>)}{left!=null&&right!=null&&<ReferenceArea x1={Math.min(left,right)} x2={Math.max(left,right)} strokeOpacity={.2} fill="#2468ef" fillOpacity={.08}/>}</LineChart></ResponsiveContainer>:<div className="chart-empty">Выберите характеристики и выполните расчёт</div>}</div>
 <div className="chart-legend">{series.map(s=><button key={s.id} style={{opacity:hidden.includes(s.id)?.35:1}} onClick={()=>setHidden(hidden.includes(s.id)?hidden.filter(x=>x!==s.id):[...hidden,s.id])} title={s.name}><svg width="23" height="8" aria-hidden="true"><line x1="0" x2="23" y1="4" y2="4" stroke={s.color} strokeWidth="2" strokeDasharray={s.dash}/></svg>{s.name}</button>)}</div><div className="chart-bottom"><span>Выделите диапазон для увеличения</span><span>{axis}</span><div><button onClick={()=>exportImage('svg')}>SVG</button><button onClick={()=>exportImage('png')}>PNG</button></div></div>
 <Dialog open={config} onOpenChange={setConfig}><DialogContent className="wide-dialog"><DialogTitle>Настройка графика</DialogTitle><DialogDescription>Выберите кривые с совместимыми единицами. Изменения не требуют пересчёта.</DialogDescription><Input aria-label="Название графика" value={plot.title} onChange={e=>onChange({...plot,title:e.target.value})}/><div className="quantity-grid">{Object.entries(quantities).map(([q,label])=><label key={q}><Checkbox disabled={!plot.quantities.includes(q)&&plot.quantities.length>0&&quantityGroup(q)!==quantityGroup(plot.quantities[0])} checked={plot.quantities.includes(q)} onCheckedChange={checked=>onChange({...plot,quantities:checked?[...plot.quantities,q]:plot.quantities.filter(x=>x!==q)})}/>{label}</label>)}</div><Choice label="Масштаб по вертикали" value={plot.scale} onChange={v=>onChange({...plot,scale:v as 'linear'|'log'})} items={[{value:'linear',label:'Линейный масштаб'},{value:'log',label:'Логарифм по основанию 10'}]}/><label className="check-row"><Checkbox checked={plot.unwrapped} onCheckedChange={v=>onChange({...plot,unwrapped:!!v})}/>Развёрнутая Δ на достоверных участках</label><Button variant="outline" onClick={()=>{onRemove();setConfig(false);}}><Trash2/>Удалить график</Button></DialogContent></Dialog></div>;
}
