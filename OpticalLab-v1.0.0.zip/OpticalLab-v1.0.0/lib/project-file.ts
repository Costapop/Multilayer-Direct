import {z} from 'zod';
import {api,Calculation,Snapshot} from './optics';
const cell=z.union([z.number().finite(),z.boolean(),z.string(),z.object({re:z.number().finite(),im:z.number().finite()})]).nullable();
const spectrum=z.object({angle:z.number().finite(),metadata:z.record(z.unknown()),data:z.record(z.array(cell)),diagnostics:z.array(z.array(z.object({code:z.string(),message:z.string(),polarization:z.string().optional(),layer:z.number().optional()}).passthrough()))}).superRefine((s,ctx)=>{
 const x=s.data.lambda_um,coord=s.data.coordinate;
 if(!x||!coord||x.length<2||x.length>20001||x.some(v=>typeof v!=='number'||v<=0)||Object.values(s.data).some(a=>a.length!==x.length)||s.diagnostics.length!==x.length)ctx.addIssue({code:'custom',message:'Повреждены массивы спектра'});
});
const calculation=z.object({project:z.record(z.unknown()),core_commit:z.string(),spectra:z.array(spectrum).min(1).max(12)});
export async function readProjectFile(file:File){
 if(file.size>80_000_000)throw Error('Размер проекта превышает 80 МБ');
 const raw=JSON.parse(await file.text());
 if(raw.format&&raw.format!=='optical-lab-project')throw Error('Неизвестный формат проекта');
 if(raw.version&&raw.version!==1)throw Error('Неизвестная версия файла');
 const project=(await api('validate',raw.project||raw)).project;
 async function readCalculation(value:unknown):Promise<Calculation>{const calc=calculation.parse(value);const p=(await api('validate',calc.project)).project;return {...calc,project:p} as Calculation;}
 const result=raw.result?await readCalculation(raw.result):null;
 const saved=z.array(z.object({id:z.string(),name:z.string(),visible:z.boolean(),color:z.string().regex(/^#[0-9a-fA-F]{6}$/),created:z.string(),calculation:z.unknown()})).max(100).parse(raw.snapshots||[]);
 const snapshots:Snapshot[]=[];for(const snap of saved)snapshots.push({...snap,id:crypto.randomUUID(),calculation:await readCalculation(snap.calculation)});
 const messages=raw.messages?z.array(z.object({role:z.enum(['user','assistant']),content:z.string()})).parse(raw.messages):undefined;
 const view=raw.view?z.object({percent:z.boolean(),axis:z.enum(['nm','um','cm^-1','rad/um']),compare:z.boolean()}).parse(raw.view):undefined;
 return {project,result,snapshots,messages,view};
}
