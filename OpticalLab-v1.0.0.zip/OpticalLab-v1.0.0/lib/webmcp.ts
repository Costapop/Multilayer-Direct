import {Calculation,Project} from './optics';
type Tool={name:string;description:string;inputSchema:object;annotations:{readOnlyHint:boolean};execute:()=>Promise<unknown>};
type Context={registerTool:(tool:Tool,options?:{signal:AbortSignal})=>Promise<void>|void;unregisterTool?:(name:string)=>void};
/** Optional API: regular browser functionality does not depend on WebMCP. */
export function registerOpticalTools(read:()=>{project:Project;result:Calculation|null},calculate:()=>Promise<Calculation|null>){
 const ctx=(document as Document&{modelContext?:Context}).modelContext||(navigator as Navigator&{modelContext?:Context}).modelContext;if(!ctx)return ()=>{};
 const abort=new AbortController();const schema={type:'object',properties:{},additionalProperties:false};
 const tools:Tool[]=[{name:'optical_lab_read_project',description:'Read the current optical coating project and the last calculated spectra. No API keys or chat history.',inputSchema:schema,annotations:{readOnlyHint:true},execute:async()=>structuredClone(read())},{name:'optical_lab_calculate',description:'Run the Python optical kernel with the parameters currently visible in the editor and display its spectra.',inputSchema:schema,annotations:{readOnlyHint:false},execute:async()=>{const result=await calculate();return result||{error:'Calculation did not complete; check the on-screen diagnostic.'};}}];
 for(const tool of tools){try{Promise.resolve(ctx.registerTool(tool,{signal:abort.signal})).catch(()=>{});}catch{}}
 return ()=>{abort.abort();for(const tool of tools)try{ctx.unregisterTool?.(tool.name);}catch{}};
}
