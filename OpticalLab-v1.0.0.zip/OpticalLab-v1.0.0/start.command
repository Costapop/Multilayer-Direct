#!/bin/zsh
cd "$(dirname "$0")" || exit 1
if command -v node >/dev/null 2>&1; then
  node scripts/start-local.mjs --open
elif [ -x "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" ]; then
  "$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node" scripts/start-local.mjs --open
else
  echo 'Установите Node.js версии 22.13 или новее. Инструкция: README.md'
fi
read -r '?Нажмите Enter, чтобы закрыть окно.'
