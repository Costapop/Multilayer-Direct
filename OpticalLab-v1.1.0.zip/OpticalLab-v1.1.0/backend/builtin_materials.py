"""Offline, versioned material definitions shipped with the application.

Definitions are embedded in saved projects; reopening a project never silently
replaces its coefficients with a newer catalog revision.
"""
from functools import lru_cache
from pathlib import Path
import json

from .models import Material

DATA = Path(__file__).parent / 'data'
ORDER = ['SiO2', 'MgF2', 'TiO2', 'Ta2O5', 'HfO2', 'Al2O3', 'Al', 'Ag', 'Au']


@lru_cache(maxsize=1)
def _catalog():
    entries = {}
    for path in sorted(DATA.glob('*.json')):
        definition = json.loads(path.read_text(encoding='utf-8'))
        material = Material.model_validate(definition)
        if material.id in entries:
            raise ValueError(f'Повторный идентификатор справочника: {material.id}')
        entries[material.id] = material
    return entries


def catalog(query=''):
    query = query.casefold().strip()
    result = []
    for material in _catalog().values():
        formula = str(material.source.get('material', material.name.split(' · ')[0]))
        if query and query not in (formula + ' ' + material.name).casefold():
            continue
        result.append({**material.model_dump(), 'material': formula,
                       'label': material.source.get('model_label', material.name),
                       'path': 'builtin:' + material.id})
    return sorted(result, key=lambda row: (ORDER.index(row['material']) if row['material'] in ORDER else len(ORDER), row['name']))


def load_material(material_id):
    try:
        return _catalog()[material_id].model_copy(deep=True)
    except KeyError:
        raise ValueError(f'Материал справочника не найден: {material_id}') from None
