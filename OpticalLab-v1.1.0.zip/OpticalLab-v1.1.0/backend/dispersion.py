"""Passive energy-domain dielectric models, using exp(-i ω t).

The multilayer kernel uses the conjugate convention. That conversion is made
only by ``core_index``; the physical dielectric function here has Im ε >= 0.
E = hc / λ is in eV for wavelength in micrometres. Oscillator strengths are
energies squared, so no conversion to angular-frequency units is needed.
"""
from __future__ import annotations

import numpy as np
from scipy.special import dawsn

from .models import Dispersion

# Exact SI h, c and elementary charge, converted to eV micrometres.
HC_EV_UM = 1.2398419843320026


def dielectric_function(energy_ev, parameters: Dispersion):
    """Evaluate Lorentz / Drude–Lorentz ε for a positive finite energy array."""
    energy = np.asarray(energy_ev, dtype=float)
    if not np.all(np.isfinite(energy)) or np.any(energy <= 0):
        raise ValueError('Энергия фотона должна быть положительной и конечной')
    # Revalidation protects callers from mutable Pydantic parameter instances.
    parameters = Dispersion.model_validate(parameters.model_dump())
    eps = np.full(energy.shape, parameters.epsilon_inf, dtype=np.complex128)
    with np.errstate(over='raise', invalid='raise', divide='raise'):
        try:
            if parameters.drude is not None:
                term = parameters.drude
                eps -= term.strength / (energy * (energy + 1j * term.gamma_ev))
            if parameters.oscillators:
                terms = np.asarray([[t.strength, t.e0_ev, t.gamma_ev] for t in parameters.oscillators])
                strength, resonance, gamma = (terms[:, i, None] for i in range(3))
                for start in range(0, energy.size, 1024):
                    e = energy.ravel()[None, start:start+1024]
                    eps.ravel()[start:start+1024] += np.sum(strength / (resonance**2 - e**2 - 1j * gamma * e), axis=0)
            if parameters.gaussian_oscillators:
                terms = np.asarray([[t.amplitude, t.e0_ev, t.sigma_ev] for t in parameters.gaussian_oscillators])
                amplitude, resonance, sigma = (terms[:, i, None] for i in range(3))
                for start in range(0, energy.size, 256):
                    e = energy.ravel()[None, start:start+256]
                    minus = (e - resonance) / sigma
                    plus = (e + resonance) / sigma
                    real = 2 * amplitude / np.sqrt(np.pi) * (dawsn(plus) - dawsn(minus))
                    # The antisymmetric partner enforces the real-time symmetry.
                    # expm1 avoids cancellation when E is small compared to E0.
                    imag = amplitude * np.exp(-minus**2) * -np.expm1(-4 * e * resonance / sigma**2)
                    eps.ravel()[start:start+256] += np.sum(real + 1j * imag, axis=0)
        except (FloatingPointError, OverflowError) as exc:
            raise ValueError('Параметры дисперсии выходят за численный диапазон') from exc
    if not np.all(np.isfinite(eps)) or np.any(eps.imag < 0):
        raise ValueError('Модель дисперсии должна давать конечную пассивную диэлектрическую функцию')
    return eps


def core_index(wavelength_um, parameters: Dispersion):
    """Return n - i κ for the exp(+i ω t) convention of the existing solver."""
    wavelength = np.asarray(wavelength_um, dtype=float)
    if not np.all(np.isfinite(wavelength)) or np.any(wavelength <= 0):
        raise ValueError('Длина волны должна быть положительной и конечной')
    eps = dielectric_function(HC_EV_UM / wavelength, parameters)
    # NumPy's principal square root selects n >= 0, κ >= 0 for Im ε >= 0.
    return np.conjugate(np.sqrt(eps))
