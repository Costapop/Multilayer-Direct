from __future__ import annotations
from typing import Literal, Any, Annotated
from pydantic import BaseModel, Field, ConfigDict, model_validator, field_validator

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)

PositiveParameter = Annotated[float, Field(gt=0, strict=True)]

class LorentzOscillator(StrictModel):
    """Energy-form oscillator: strength has units eV², energies have units eV."""
    strength: PositiveParameter
    e0_ev: PositiveParameter
    gamma_ev: PositiveParameter

class DrudeTerm(StrictModel):
    strength: PositiveParameter
    gamma_ev: PositiveParameter

class GaussianOscillator(StrictModel):
    """Antisymmetric Gaussian ε₂ with its causal Dawson ε₁ partner."""
    amplitude: PositiveParameter
    e0_ev: PositiveParameter
    sigma_ev: PositiveParameter

class Dispersion(StrictModel):
    epsilon_inf: PositiveParameter = 1.0
    oscillators: list[LorentzOscillator] = Field(default_factory=list, max_length=64)
    drude: DrudeTerm | None = None
    gaussian_oscillators: list[GaussianOscillator] = Field(default_factory=list, max_length=1024)

    @model_validator(mode='after')
    def has_response(self):
        if not self.oscillators and not self.gaussian_oscillators and self.drude is None:
            raise ValueError('Осцилляторная модель требует хотя бы один осциллятор или член Друде')
        return self

class Material(StrictModel):
    id: str
    name: str
    model: Literal['constant','cauchy','sellmeier','tabulated','library','oscillator'] = 'constant'
    n: float = Field(default=1.5, ge=0)
    kappa: float = Field(default=0, ge=0)
    coefficients: list[float] = Field(default_factory=list)
    range_um: list[float] | None = None
    table: list[list[float]] = Field(default_factory=list)
    source: dict[str, Any] = Field(default_factory=dict)
    components: list[dict[str, Any]] = Field(default_factory=list)
    transparent_approximation: bool = False
    dispersion: Dispersion | None = None
    @model_validator(mode='after')
    def check_range(self):
        if self.range_um is not None and (len(self.range_um)!=2 or not 0<self.range_um[0]<self.range_um[1]):raise ValueError('Диапазон материала: два возрастающих положительных числа в мкм')
        if self.model in ['cauchy','sellmeier','oscillator'] and self.range_um is None:raise ValueError('Для модели дисперсии укажите диапазон применимости')
        if self.model=='oscillator' and self.dispersion is None:raise ValueError('Для осцилляторной модели укажите параметры дисперсии')
        if self.model!='oscillator' and self.dispersion is not None:raise ValueError('Параметры осцилляторов допустимы только для модели oscillator')
        return self

class LayerInput(StrictModel):
    id: str
    name: str = ''
    material_id: str
    thickness: float = Field(ge=0)
    unit: Literal['nm','um','mm','cm','m'] = 'nm'
    @field_validator('thickness',mode='before')
    @classmethod
    def no_boolean(cls,v):
        if isinstance(v,bool):raise ValueError('Толщина должна быть числом, не логическим значением')
        return v

class Settings(StrictModel):
    kind: Literal['wavelength','spectroscopic_wavenumber','angular_wavenumber'] = 'wavelength'
    unit: str = 'nm'
    start: float = Field(default=400, gt=0)
    stop: float = Field(default=800, gt=0)
    count: int = Field(default=401, ge=2, le=20001)
    angles: list[float] = Field(default_factory=lambda:[30], min_length=1, max_length=12)
    refine: bool = False
    @model_validator(mode='after')
    def limits(self):
        if self.stop <= self.start: raise ValueError('Конец диапазона должен быть больше начала')
        if any(not 0 <= a < 90 for a in self.angles): raise ValueError('Угол от нормали: 0 ≤ θ < 90°')
        return self

class PlotInput(StrictModel):
    id: str
    title: str
    quantities: list[str] = Field(default_factory=lambda:['Rs','Rp'])
    scale: Literal['linear','log'] = 'linear'
    unwrapped: bool = False
    @model_validator(mode='after')
    def quantities_valid(self):
        allowed={'Rs','Rp','Ts','Tp','As','Ap','R','T','A','psi_deg','delta_deg','r_s_abs','r_p_abs','r_s_re','r_s_im','r_p_re','r_p_im','rho_re','rho_im','rho_abs','t_tan_s_abs','t_tan_p_abs','phase_t_s','phase_t_p','r_s_arg','r_p_arg','rho_arg','t_tan_s_re','t_tan_s_im','t_tan_p_re','t_tan_p_im'}
        for q in self.quantities:
            if q not in allowed:raise ValueError(f'Неизвестная характеристика {q}')
        groups={('energy' if q in {'Rs','Rp','Ts','Tp','As','Ap','R','T','A'} else 'angle' if q in {'psi_deg','delta_deg','phase_t_s','phase_t_p','r_s_arg','r_p_arg','rho_arg'} else 'amplitude') for q in self.quantities}
        if len(groups)>1:raise ValueError('Разместите энергию, углы и амплитуды на отдельных графиках')
        return self

class Project(StrictModel):
    schema_version: Literal['1.0'] = '1.0'
    name: str = 'Новое покрытие'
    layers: list[LayerInput] = Field(default_factory=list, max_length=1500)
    materials: list[Material]
    ambient_id: str = 'air'
    substrate_id: str = 'glass'
    substrate_mode: Literal['semi_infinite_lossless'] = 'semi_infinite_lossless'
    settings: Settings = Field(default_factory=Settings)
    plots: list[PlotInput] = Field(default_factory=lambda:[PlotInput(id='reflection',title='Отражение'),PlotInput(id='transmission',title='Пропускание',quantities=['Ts','Tp'])])
    @model_validator(mode='after')
    def references(self):
        ids=[m.id for m in self.materials]
        if len(ids)!=len(set(ids)): raise ValueError('Идентификаторы материалов должны быть уникальны')
        if len({l.id for l in self.layers}) != len(self.layers): raise ValueError('Идентификаторы слоёв должны быть уникальны')
        for mid in [self.ambient_id,self.substrate_id]+[l.material_id for l in self.layers]:
            if mid not in ids: raise ValueError(f'Материал {mid} не определён')
        if len(self.layers)*self.settings.count*len(self.settings.angles)>6_000_000: raise ValueError('Уменьшите число точек, углов или слоёв: бюджет 6 млн слой-точек')
        return self

def demo_project():
    return Project(name='Брэгговское зеркало · 6 пар',materials=[Material(id='air',name='Воздух',n=1),Material(id='glass',name='Стекло · n = 1,52',n=1.52),Material(id='H',name='H · n = 2,10',n=2.1),Material(id='L',name='L · n = 1,45',n=1.45)],layers=[LayerInput(id=f'layer-{i+1}',material_id='H' if i%2==0 else 'L',thickness=550/(4*(2.1 if i%2==0 else 1.45)),name=f'Слой {i+1}') for i in range(12)])
