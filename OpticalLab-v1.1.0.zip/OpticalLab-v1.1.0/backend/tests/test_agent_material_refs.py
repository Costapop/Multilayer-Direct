"""Assistant material references hydrate locally, without a live API request."""
import copy
import json
import unittest
from unittest.mock import patch

from backend import agent
from backend.builtin_materials import catalog, load_material
from backend.models import Material, LayerInput, demo_project


def tool_call(name, arguments, call_id='1'):
    return {'output':[{'type':'function_call','name':name,'call_id':call_id,
                       'arguments':json.dumps(arguments)}]}


def update_call(project, calculate=False):
    return tool_call('update_project', {'project_json':json.dumps(project),
                     'summary':'Изменено','calculate':calculate,'save_previous':False})


FINISH = {'output':[{'type':'message','content':[{'type':'output_text','text':'Готово.'}]}]}


class AgentMaterialReferenceTests(unittest.TestCase):
    def run_chat(self, project, outputs):
        requests=[]
        replies=iter([*outputs,FINISH])
        class Response:
            is_success=True
            def __init__(self, value):self.value=value
            def json(self):return self.value
        def post(_url, **kwargs):
            requests.append(copy.deepcopy(kwargs['json']))
            return Response(next(replies))
        with patch.object(agent.httpx.Client,'post',side_effect=post):
            result=agent.chat('Увеличь толщину первого слоя на 10 нм.',[],project,{'key':'mock-key'})
        return result,requests

    def project_with_silica(self):
        project=demo_project()
        material=load_material(next(r['id'] for r in catalog() if r['material']=='SiO2'))
        project.materials.append(material)
        project.layers=[LayerInput(id='film',material_id=material.id,thickness=100)]
        project.settings.count=3;project.settings.angles=[0]
        return project,material

    def test_compact_thickness_update_restores_exact_material(self):
        project,material=self.project_with_silica()
        compact=agent.project_for_agent(project)
        compact['layers'][0]['thickness']=110
        reference=compact['materials'][-1]
        self.assertNotIn('dispersion',reference)
        # Even supplied replacement coefficients must not modify the dataset.
        reference['dispersion']={'epsilon_inf':999}
        reference['range_um']=[.001,10000]
        reference['source']['invented']='discard this'
        result,_=self.run_chat(project,[update_call(compact,calculate=True)])
        self.assertEqual(result['project']['layers'][0]['thickness'],110)
        self.assertEqual(result['project']['materials'][-1],material.model_dump())
        self.assertIsNotNone(result['calculation'])
        self.assertEqual(result['calculation']['project']['materials'][-1],material.model_dump())

    def test_unknown_dataset_reference_is_rejected(self):
        project,_=self.project_with_silica()
        compact=agent.project_for_agent(project)
        compact['materials'][-1]['source']['dataset']='builtin:unknown'
        result,requests=self.run_chat(project,[update_call(compact)])
        self.assertIsNone(result['project'])
        output=next(m for m in requests[-1]['input'] if m.get('type')=='function_call_output')
        error=json.loads(output['output'])
        self.assertFalse(error['applied'])
        self.assertIn('Сначала загрузите',error['error'])

    def test_loaded_material_is_compact_but_saved_definition_is_complete(self):
        project=demo_project();project.settings.count=3
        row=next(r for r in catalog() if r['material']=='MgF2')
        material=load_material(row['id'])
        compact=agent.project_for_agent(project)
        compact['materials'].append(agent.material_for_agent(material))
        compact['layers'][0]['material_id']=material.id
        result,requests=self.run_chat(project,[tool_call('load_material',{'path':row['path']}),update_call(compact)])
        output=next(m for m in requests[1]['input'] if m.get('type')=='function_call_output')
        loaded=json.loads(output['output'])
        self.assertNotIn('dispersion',loaded)
        self.assertLess(len(output['output']),3000)
        self.assertEqual(result['project']['materials'][-1],material.model_dump())

    def test_six_dielectric_prompt_and_search_remain_small(self):
        project=demo_project()
        for row in catalog():
            if row['material'] not in ['Al','Ag','Au']:
                project.materials.append(load_material(row['id']))
        _,requests=self.run_chat(project,[])
        self.assertLess(len(json.dumps(requests[0],ensure_ascii=False)),30000)
        rows=agent.search('')
        self.assertEqual(len(rows),9)
        self.assertLess(len(json.dumps(rows,ensure_ascii=False)),10000)
        self.assertTrue(all('dispersion' not in row and 'source' not in row for row in rows))

    def test_existing_public_library_reference_is_preserved(self):
        project=demo_project()
        material=Material(id='public',name='Public film',model='library',range_um=[.4,.8],
            components=[{'type':'tabulated nk','values':[[.4,1.5,.01],[.8,1.4,.02]]}],
            source={'dataset':'main/example/nk/example.yml','version':'saved-version','has_kappa':True})
        project.materials.append(material)
        project.layers=[LayerInput(id='film',material_id=material.id,thickness=100)]
        project.settings.count=3
        compact=agent.project_for_agent(project)
        compact['materials'][-1]['name']='Renamed film'
        result,_=self.run_chat(project,[update_call(compact)])
        expected=material.model_dump();expected['name']='Renamed film'
        self.assertEqual(result['project']['materials'][-1],expected)

    def test_custom_material_without_dataset_stays_explicit(self):
        custom=Material(id='custom',name='Custom oscillator',model='oscillator',range_um=[.2,2],
            dispersion={'oscillators':[{'strength':2.,'e0_ev':4.,'gamma_ev':.1}]})
        self.assertEqual(agent.material_for_agent(custom),custom.model_dump())

    def test_saved_definitions_with_same_dataset_are_not_merged(self):
        project,first=self.project_with_silica()
        second=first.model_copy(deep=True)
        second.id='second-version'
        second.dispersion.gaussian_oscillators[0].amplitude *= 1.1
        project.materials.append(second)
        result,_=self.run_chat(project,[update_call(agent.project_for_agent(project))])
        self.assertEqual(result['project']['materials'][-2],first.model_dump())
        self.assertEqual(result['project']['materials'][-1],second.model_dump())


if __name__=='__main__':
    unittest.main()
