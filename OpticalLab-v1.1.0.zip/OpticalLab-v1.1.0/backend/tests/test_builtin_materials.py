"""End-to-end checks for the offline release catalog and the optical solver."""
import json
import unittest
from unittest.mock import patch

import numpy as np
from fastapi.testclient import TestClient

from backend.app import app
from backend.builtin_materials import catalog, load_material
from backend.models import Project, LayerInput, demo_project
from backend.solver import calculate, material_function
from backend import agent


class BuiltinCatalogTests(unittest.TestCase):
    def test_nine_materials_available_without_network(self):
        with patch('httpx.get', side_effect=AssertionError('Network used')):
            client = TestClient(app)
            rows = client.get('/materials/builtin').json()
            self.assertEqual({r['material'] for r in rows},
                             {'SiO2','MgF2','TiO2','Ta2O5','HfO2','Al2O3','Al','Ag','Au'})
            self.assertEqual(len(rows), 9)
            for row in rows:
                response = client.get('/materials/builtin/' + row['id'])
                self.assertEqual(response.status_code, 200)
                material = response.json()
                self.assertEqual(material['model'], 'oscillator')
                self.assertTrue(material['dispersion'])
                self.assertTrue(material['source']['references'])
                self.assertTrue(material['source']['has_kappa'])
                self.assertFalse(material['transparent_approximation'])
                preview = client.post('/materials/preview', json={'material': material})
                self.assertEqual(preview.status_code, 200, preview.text)
                self.assertTrue(np.all(np.isfinite(preview.json()['n'])))
                self.assertTrue(np.all(np.asarray(preview.json()['kappa']) >= 0))
            self.assertEqual(client.get('/materials/builtin/missing').status_code, 404)

    def test_single_film_matches_independent_fresnel_formula_in_three_bands(self):
        # Independent normal-incidence Air / dispersive film / glass calculation.
        for row in catalog():
            for start, stop in [(240,350),(400,750),(2500,5000)]:
                with self.subTest(material=row['material'], band=(start,stop)):
                    m = load_material(row['id'])
                    p = demo_project()
                    p.materials.append(m)
                    p.layers = [LayerInput(id='film',material_id=m.id,thickness=43)]
                    p.settings.start=start; p.settings.stop=stop
                    p.settings.count=13; p.settings.angles=[0]
                    data=calculate(p)['spectra'][0]['data']
                    wavelength=np.linspace(start,stop,13)/1000
                    index=material_function(m)(2*np.pi/wavelength)
                    ns=1.52
                    r01=(1-index)/(1+index)
                    r12=(index-ns)/(index+ns)
                    phase=np.exp(-2j*np.pi*index*.043/wavelength)
                    den=1+r01*r12*phase**2
                    reflection=np.abs((r01+r12*phase**2)/den)**2
                    transmission=ns*np.abs((2/(1+index))*(2*index/(index+ns))*phase/den)**2
                    np.testing.assert_allclose(data['Rs'],reflection,rtol=2e-10,atol=2e-12)
                    np.testing.assert_allclose(data['Ts'],transmission,rtol=2e-10,atol=2e-12)
                    for q in ['Rs','Rp','Ts','Tp','As','Ap']:
                        self.assertTrue(np.all(np.asarray(data[q]) >= -2e-12), q)
                        self.assertTrue(np.all(np.asarray(data[q]) <= 1+2e-12), q)

    def test_range_is_enforced_and_json_reopening_reproduces_spectrum(self):
        for row in catalog():
            with self.subTest(material=row['material']):
                m=load_material(row['id']); low,high=m.range_um
                f=material_function(m)
                for wavelength in [low*.999,high*1.001]:
                    with self.assertRaisesRegex(ValueError,'диапазон'):
                        f(2*np.pi/np.asarray([wavelength]))
                p=demo_project();p.materials.append(m)
                p.layers=[LayerInput(id='film',material_id=m.id,thickness=25)]
                p.settings.count=5;p.settings.angles=[0,60]
                first=calculate(p)
                restored=Project.model_validate_json(json.dumps(first['project'],allow_nan=False))
                second=calculate(restored)
                self.assertEqual(first['spectra'],second['spectra'])

    def test_ai_search_and_load_use_same_offline_definitions(self):
        with patch('httpx.get', side_effect=AssertionError('Network used')):
            for composition in ['SiO2','MgF2','TiO2','Ta2O5','HfO2','Al2O3','Al','Ag','Au']:
                rows=agent.search(composition)
                row=next(r for r in rows if r['material']==composition)
                material=agent.load_material(row['path'])
                self.assertEqual(material.model_dump(),load_material(row['id']).model_dump())


if __name__=='__main__':
    unittest.main()
