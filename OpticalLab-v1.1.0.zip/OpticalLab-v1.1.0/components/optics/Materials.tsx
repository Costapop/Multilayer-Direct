'use client';

import {useEffect,useState} from 'react';
import {Search,Plus,BookOpen,Loader2,ExternalLink,Check,FlaskConical} from 'lucide-react';
import {CartesianGrid,Line,LineChart,ResponsiveContainer,Tooltip,XAxis,YAxis} from 'recharts';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Dialog,DialogContent,DialogTitle,DialogDescription} from '@/components/ui/dialog';
import {Tabs,TabsList,TabsTrigger,TabsContent} from '@/components/ui/tabs';
import {Checkbox} from '@/components/ui/checkbox';
import {Textarea} from '@/components/ui/textarea';
import Choice from './Choice';
import {Project,Material,BuiltinMaterial,api,mat} from '@/lib/optics';

type Coefficient={symbol:string;value:string;unit:string;note:string};
type Preview={wavelength_nm:number[];n:number[];kappa:number[]};
type LibraryItem={path:string;material:string;label:string};
type MaterialProps={open:boolean;onClose:()=>void;project:Project;onChange:(p:Project)=>void};
const numberFormat=new Intl.NumberFormat('ru-RU',{maximumSignificantDigits:6});
const scientificFormat=new Intl.NumberFormat('ru-RU',{notation:'scientific',maximumSignificantDigits:3});
const format=(n:number)=>n!==0&&(Math.abs(n)<.0001||Math.abs(n)>=100000)?scientificFormat.format(n):numberFormat.format(n);
const text=(value:unknown)=>typeof value==='string'?value:typeof value==='number'?String(value):'';
const strings=(value:unknown):string[]=>Array.isArray(value)?value.map(text).filter(Boolean):text(value)?[text(value)]:[];
function rangeLabel(range:number[]|null|undefined){return range?.length===2?`${format(range[0])}–${format(range[1])} мкм`:'Диапазон не указан';}
function modelLabel(m:{model:string;source:Record<string,unknown>}){return text(m.source?.model_name)||text(m.source?.model_label)||({constant:'Постоянные n и κ',cauchy:'Коши',sellmeier:'Зельмейер',tabulated:'Таблица n и κ',library:'Публичный набор',oscillator:'Осцилляторная модель'}[m.model]??m.model);}
function coefficientsOf(m:Material):Coefficient[]{
 const saved=m.source?.coefficient_table;
 if(Array.isArray(saved)&&saved.length)return saved.filter(v=>v&&typeof v==='object').map(v=>({symbol:text(v.symbol),value:typeof v.value==='number'?String(v.value):text(v.value),unit:text(v.unit),note:text(v.note)}));
 if(!m.dispersion)return [];
 const rows:Coefficient[]=[{symbol:'ε∞',value:String(m.dispersion.epsilon_inf),unit:'—',note:'Высокочастотный вклад'}];
 if(m.dispersion.drude)rows.push({symbol:'Sᴅ',value:String(m.dispersion.drude.strength),unit:'эВ²',note:'Сила члена Друде'},{symbol:'Γᴅ',value:String(m.dispersion.drude.gamma_ev),unit:'эВ',note:'Затухание свободных носителей'});
 m.dispersion.oscillators.forEach((o,i)=>rows.push({symbol:`S${i+1}`,value:String(o.strength),unit:'эВ²',note:'Сила осциллятора'},{symbol:`E${i+1}`,value:String(o.e0_ev),unit:'эВ',note:'Энергия резонанса'},{symbol:`Γ${i+1}`,value:String(o.gamma_ev),unit:'эВ',note:'Затухание'}));
 m.dispersion.gaussian_oscillators?.forEach((o,i)=>rows.push({symbol:`G${i+1}`,value:`A = ${o.amplitude}; E₀ = ${o.e0_ev}; σ = ${o.sigma_ev}`,unit:'A: 1; E₀, σ: эВ',note:'Гауссов осциллятор'}));
 return rows;
}
function SourceLinks({source}:{source:Record<string,unknown>}){
 const references=Array.isArray(source.references)?source.references.filter(v=>v&&typeof v==='object'):[];
 const url=text(source.url);
 return <div className="builtin-references">{references.map((r,i)=>/^https?:\/\//.test(text(r.url))?<a key={i} href={text(r.url)} target="_blank" rel="noreferrer">{text(r.title)||text(r.url)}<ExternalLink size={13}/></a>:<p key={i}>{text(r.title)}</p>)}{!references.length&&strings(source.references).map((r,i)=><p key={i}>{r}</p>)}{!references.length&&/^https?:\/\//.test(url)&&<a href={url} target="_blank" rel="noreferrer">Исходный набор<ExternalLink size={13}/></a>}</div>;
}
function IndexPreview({material}:{material:Material}){
 const [band,setBand]=useState('all');
 const [response,setResponse]=useState<{key:string;preview:Preview|null;error:string}|null>(null);
 const [minimum,maximum]=material.range_um??[.4,.8];
 const bands=[{id:'all',label:'Весь диапазон',start:minimum,stop:maximum},{id:'uv',label:'УФ',start:Math.max(minimum,.2),stop:Math.min(maximum,.4)},{id:'visible',label:'Видимый',start:Math.max(minimum,.4),stop:Math.min(maximum,.78)},{id:'ir',label:'ИК',start:Math.max(minimum,.78),stop:maximum}];
 const activeBand=bands.find(b=>b.id===band&&b.start<b.stop)??bands[0];
 const {start,stop}=activeBand,requestKey=`${material.id}:${start}:${stop}`;
 useEffect(()=>{
  let active=true;
  api('materials/preview',{material,range_um:[start,stop]}).then((v:Preview)=>{if(active)setResponse({key:requestKey,preview:v,error:''});}).catch(e=>{if(active)setResponse({key:requestKey,preview:null,error:(e as Error).message});});
  return ()=>{active=false;};
 },[material,start,stop,requestKey]);
 const current=response?.key===requestKey?response:null,preview=current?.preview,error=current?.error;
 const points=preview?.wavelength_nm.map((w,i)=>({wavelength:w/1000,n:preview.n[i],kappa:preview.kappa[i]}))??[];
 return <section className="builtin-section"><h3>Дисперсия n и κ</h3><div className="preview-bands" role="group" aria-label="Диапазон предпросмотра">{bands.map(b=><button key={b.id} aria-pressed={activeBand.id===b.id} disabled={b.start>=b.stop} title={b.start<b.stop?rangeLabel([b.start,b.stop]):'За пределами диапазона модели'} onClick={()=>setBand(b.id)}>{b.label}</button>)}</div><p className="preview-range-note">{rangeLabel([start,stop])}{activeBand.id==='all'?' · логарифмическая шкала λ':''}</p>{error?<p className="warning-text">Предпросмотр недоступен: {error}</p>:!preview?<div className="builtin-loading"><Loader2 className="spin" size={16}/>Расчёт дисперсии…</div>:<div className="index-preview">{(['n','kappa'] as const).map((quantity,i)=><div className="index-preview-panel" key={quantity}><span>{quantity==='n'?'n · показатель преломления':'κ · коэффициент экстинкции'}</span><div className="index-preview-chart"><ResponsiveContainer width="100%" height="100%"><LineChart data={points} margin={{top:8,right:12,left:-22,bottom:0}}><CartesianGrid stroke="#eaf0f7" vertical={false}/><XAxis dataKey="wavelength" type="number" scale={activeBand.id==='all'?'log':'linear'} domain={['dataMin','dataMax']} tickFormatter={v=>format(v)} tick={{fontSize:10}} tickLine={false} axisLine={false} tickCount={3}/><YAxis tickFormatter={v=>format(v)} tick={{fontSize:10}} tickLine={false} axisLine={false} width={58} domain={['auto','auto']}/><Tooltip labelFormatter={v=>`λ = ${format(Number(v))} мкм`} formatter={v=>[format(Number(v)),quantity==='n'?'n':'κ']}/><Line dataKey={quantity} stroke={i?'#d66c32':'#2468ef'} dot={false} strokeWidth={2} isAnimationActive={false}/></LineChart></ResponsiveContainer></div><small>Длина волны λ, мкм</small></div>)}</div>}</section>;
}
function FitAccuracy({material}:{material:Material}){
 const raw=material.source?.fit_error;
 if(!raw||typeof raw!=='object'||Array.isArray(raw))return null;
 const report=raw as Record<string,unknown>;
 const groups=[['reference_nodes',`Весь диапазон · ${rangeLabel(material.range_um)}`],['held_out_nodes','Контрольные узлы'],['uv','УФ · 0,2–0,4 мкм'],['visible','Видимый · 0,4–0,78 мкм'],['near_ir','Ближний ИК · 0,78–2,5 мкм'],['mid_ir','Средний ИК · 2,5–25 мкм']];
 const rows=groups.flatMap(([key,label])=>{
  const value=report[key];
  if(!value||typeof value!=='object'||Array.isArray(value))return [];
  const metrics=value as Record<string,unknown>,n=metrics.max_abs_n,kappa=metrics.max_abs_kappa;
  return typeof n==='number'&&Number.isFinite(n)&&typeof kappa==='number'&&Number.isFinite(kappa)?[{key,label,n,kappa}]:[];
 });
 if(!rows.length)return null;
 return <section className="builtin-section"><h3>Точность аппроксимации</h3><p>Максимальные абсолютные отклонения n и κ от исходного табличного набора. Неопределённость исходных измерений здесь не оценивается.</p><div className="coefficient-scroll"><table className="coefficient-table fit-error-table"><thead><tr><th>Область проверки</th><th>max |Δn|</th><th>max |Δκ|</th></tr></thead><tbody>{rows.map(row=><tr key={row.key}><td>{row.label}</td><td>{format(row.n)}</td><td>{format(row.kappa)}</td></tr>)}</tbody></table></div>{rows.some(row=>row.key==='held_out_nodes')&&<p className="fit-error-note">Контрольные узлы не участвовали в подгонке коэффициентов.</p>}</section>;
}
function ModelDetails({material,preview=false}:{material:Material;preview?:boolean}){
 const source=material.source??{},formulas=strings(source.formula),rows=coefficientsOf(material),limitations=strings(source.limitations);
 const conditions=typeof source.conditions==='string'?source.conditions:source.conditions&&typeof source.conditions==='object'?Object.entries(source.conditions).map(([key,value])=>`${key}: ${text(value)||JSON.stringify(value)}`).join(' · '):'';
 return <div className="builtin-model-details">
  {preview&&<IndexPreview key={material.id} material={material}/>}
  <section className="builtin-section"><h3>Формула модели</h3>{formulas.length?<div className="dispersion-formulas">{formulas.map((formula,i)=><div key={i}>{formula}</div>)}</div>:<p className="muted">Комплексная диэлектрическая функция определяется коэффициентами осцилляторов.</p>}</section>
  {!!rows.length&&<section className="builtin-section"><details className="coefficient-details" open={rows.length<=30}><summary>Коэффициенты набора <span>{rows.length} строк</span></summary><div className="coefficient-scroll"><table className="coefficient-table"><thead><tr><th>Параметр</th><th>Значение</th><th>Единица</th><th>Описание</th></tr></thead><tbody>{rows.map((row,i)=><tr key={i}><td>{row.symbol}</td><td>{row.value}</td><td>{row.unit||'—'}</td><td>{row.note}</td></tr>)}</tbody></table></div></details></section>}
  <FitAccuracy material={material}/>
  <section className="builtin-section builtin-limits"><h3>Область применения</h3><p><strong>{rangeLabel(material.range_um)}</strong>{text(source.range_note)&&` · ${text(source.range_note)}`}</p>{conditions&&<p>{conditions}</p>}{!!limitations.length&&<ul>{limitations.map((note,i)=><li key={i}>{note}</li>)}</ul>}</section>
  <section className="builtin-section"><h3>Источники</h3><SourceLinks source={source}/>{!!source.version&&<p className="builtin-version">Версия набора: {text(source.version)}</p>}</section>
 </div>;
}

export default function Materials(props:MaterialProps){return props.open?<MaterialDialog {...props}/>:null;}
function MaterialDialog({open,onClose,project,onChange}:MaterialProps){
 const initial=project.materials[0]??mat('new','Новый материал',1.5);
 const [draft,setDraft]=useState<Material>(()=>structuredClone(initial));
 const [query,setQuery]=useState(''),[list,setList]=useState<LibraryItem[]>([]),[busy,setBusy]=useState(false),[error,setError]=useState(''),[tab,setTab]=useState('builtin'),[coeff,setCoeff]=useState(initial.coefficients.join('; ')),[table,setTable]=useState(initial.table.map(r=>r.join('\t')).join('\n'));
 const [builtins,setBuiltins]=useState<BuiltinMaterial[]>([]),[builtinQuery,setBuiltinQuery]=useState(''),[selectedId,setSelectedId]=useState(''),[detail,setDetail]=useState<{id:string;material:Material|null;error:string}|null>(null),[catalogBusy,setCatalogBusy]=useState(true),[catalogError,setCatalogError]=useState(''),[notice,setNotice]=useState('');
 function edit(m:Material){setDraft(structuredClone(m));setCoeff(m.coefficients.join('; '));setTable(m.table.map(r=>r.join('\t')).join('\n'));}
 const selected=detail?.id===selectedId?detail.material:null,detailBusy=!!selectedId&&detail?.id!==selectedId,detailError=detail?.id===selectedId?detail.error:'';
 useEffect(()=>{
  let active=true;
  api('materials/builtin').then((items:BuiltinMaterial[])=>{if(!active)return;setBuiltins(items);setSelectedId(current=>items.some(m=>m.id===current)?current:items[0]?.id??'');}).catch(e=>{if(active)setCatalogError((e as Error).message);}).finally(()=>{if(active)setCatalogBusy(false);});
  return ()=>{active=false;};
 },[]);
 useEffect(()=>{
  if(!selectedId)return;
  let active=true;
  api('materials/builtin/'+encodeURIComponent(selectedId)).then((m:Material)=>{if(active)setDetail({id:selectedId,material:m,error:''});}).catch(e=>{if(active)setDetail({id:selectedId,material:null,error:(e as Error).message});});
  return ()=>{active=false;};
 },[selectedId]);
 async function search(){setBusy(true);setError('');try{setList(await api('materials?q='+encodeURIComponent(query)));}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 async function load(path:string){setBusy(true);setError('');try{edit(await api('materials/load?path='+encodeURIComponent(path)));setTab('project');}catch(e){setError((e as Error).message);}finally{setBusy(false);}}
 function save(){try{const m={...draft,id:draft.id==='new'?crypto.randomUUID():draft.id};if(['cauchy','sellmeier'].includes(m.model)){m.coefficients=coeff.split(';').map(x=>Number(x.trim().replace(',','.')));if(m.coefficients.some(x=>!Number.isFinite(x)))throw Error('Проверьте коэффициенты');}if(m.model==='tabulated'){m.table=table.trim().split('\n').filter(Boolean).map(row=>row.trim().split(/[\t; ]+/).map(x=>Number(x.replace(',','.'))));if(m.table.some(r=>r.length!==3||r.some(x=>!Number.isFinite(x))))throw Error('В каждой строке нужны λ [нм], n, κ');}onChange({...project,materials:project.materials.some(x=>x.id===m.id)?project.materials.map(x=>x.id===m.id?m:x):[...project.materials,m]});onClose();}catch(e){setError((e as Error).message);}}
 const existing=selected&&project.materials.find(m=>m.id===selected.id||!!selected.source.builtin_id&&m.source.builtin_id===selected.source.builtin_id);
 function addBuiltin(){if(!selected||existing)return;const m=structuredClone(selected);onChange({...project,materials:[...project.materials,m]});setNotice(`${m.name} добавлен. Теперь его можно выбрать для слоя.`);}
 const normalizedQuery=builtinQuery.normalize('NFKC').toLocaleLowerCase().replace(/\s/g,'');
 const filteredBuiltins=builtins.filter(m=>`${m.material} ${m.name} ${modelLabel(m)}`.normalize('NFKC').toLocaleLowerCase().replace(/\s/g,'').includes(normalizedQuery));
 return <Dialog open={open} onOpenChange={v=>!v&&onClose()}><DialogContent className="wide-dialog material-dialog">
  <DialogTitle>Материалы и дисперсия</DialogTitle>
  <DialogDescription>Выберите готовый набор с поглощением или настройте материал проекта.</DialogDescription>
  <Tabs value={tab} onValueChange={v=>{setTab(v);setError('');}}>
   <TabsList className="material-tabs"><TabsTrigger value="builtin"><FlaskConical size={15}/>Готовые материалы</TabsTrigger><TabsTrigger value="project">В проекте</TabsTrigger><TabsTrigger value="library" onClick={()=>{if(!list.length)void search();}}>Публичная библиотека</TabsTrigger></TabsList>
   <TabsContent value="builtin">
    <div className="builtin-intro"><span className="offline-badge"><Check size={13}/>Доступны без интернета</span><p>Формулы, коэффициенты и источники уже включены. Выберите набор, подходящий вашему диапазону и типу образца.</p></div>
    {catalogBusy&&!builtins.length?<div className="builtin-loading"><Loader2 className="spin" size={18}/>Загрузка готовых материалов…</div>:<div className="builtin-layout">
     <aside className="builtin-catalog"><div className="builtin-search"><Search size={15}/><Input aria-label="Поиск готового материала" placeholder="Материал или формула…" value={builtinQuery} onChange={e=>setBuiltinQuery(e.target.value)}/></div><div className="builtin-list" aria-label="Готовые материалы">{filteredBuiltins.map(m=><button key={m.id} className={m.id===selectedId?'selected':''} onClick={()=>{setSelectedId(m.id);setNotice('');}} aria-pressed={m.id===selectedId}><span className="builtin-material-symbol">{m.material||m.name}</span><strong>{m.name}</strong><small>{modelLabel(m)}</small><span className="builtin-card-range">{rangeLabel(m.range_um)}</span></button>)}{!filteredBuiltins.length&&!catalogError&&<p className="muted builtin-empty">Материал не найден. Попробуйте SiO2, TiO2 или Ag.</p>}</div></aside>
     <div className="builtin-detail">{detailBusy?<div className="builtin-loading"><Loader2 className="spin" size={18}/>Загрузка модели…</div>:selected?<><div className="builtin-detail-heading"><div><span className="builtin-model-label">{modelLabel(selected)}</span><h2>{selected.name}</h2></div><span className="builtin-range-badge">{rangeLabel(selected.range_um)}</span></div>{!!selected.source.description&&<p className="builtin-description">{text(selected.source.description)}</p>}<div className="builtin-add-row">{existing?<Button variant="outline" onClick={()=>{edit(existing);setTab('project');}}><Check size={16}/>В проекте · открыть</Button>:<Button onClick={addBuiltin}><Plus size={16}/>Добавить в проект</Button>}<span>n и κ рассчитываются по модели</span></div>{notice&&<p className="builtin-notice" role="status">{notice}</p>}<ModelDetails material={selected} preview/></>:!catalogError&&!detailError&&<p className="muted builtin-empty">Выберите материал из списка.</p>}</div>
    </div>}{(catalogError||detailError)&&<div className="inline-error" role="alert">{catalogError||detailError}</div>}
   </TabsContent>
   <TabsContent value="project"><div className="material-layout"><div className="material-list">{project.materials.map(m=><button key={m.id} className={m.id===draft.id?'selected':''} onClick={()=>edit(m)}><strong>{m.name}</strong><small>{m.model==='constant'?`n = ${m.n}, κ = ${m.kappa}`:modelLabel(m)}</small></button>)}<Button variant="outline" onClick={()=>edit(mat('new','Новый материал',1.5))}><Plus/>Новый материал</Button><Button variant="ghost" onClick={()=>setTab('builtin')}><BookOpen/>Готовые материалы</Button></div><div className="material-form"><label>Название<Input value={draft.name} onChange={e=>setDraft({...draft,name:e.target.value})}/></label>
    {draft.model==='oscillator'?<div className="project-builtin-summary"><span className="builtin-model-label">{modelLabel(draft)}</span><p>Готовая модель с поглощением · {rangeLabel(draft.range_um)}</p><ModelDetails material={draft}/></div>:<label>Модель<Choice label="Модель дисперсии" value={draft.model} onChange={v=>setDraft({...draft,model:v as Material['model']})} items={[{value:'constant',label:'Постоянные n и κ'},{value:'cauchy',label:'Коши · A + B/λ² + C/λ⁴'},{value:'sellmeier',label:'Зельмейер · 3 резонанса'},{value:'tabulated',label:'Таблица λ, n, κ'},{value:'library',label:'Набор из библиотеки'}]}/></label>}
    {draft.model==='constant'&&<div className="settings-grid"><label>n<Input type="number" step="any" value={draft.n} onChange={e=>setDraft({...draft,n:+e.target.value})}/></label><label>κ ≥ 0<Input type="number" min="0" step="any" value={draft.kappa} onChange={e=>setDraft({...draft,kappa:+e.target.value})}/></label></div>}
    {['cauchy','sellmeier'].includes(draft.model)&&<><label>{draft.model==='cauchy'?'A; B [мкм²]; C [мкм⁴]':'B₁; C₁; B₂; C₂; B₃; C₃ (C в мкм²)'}<Input value={coeff} onChange={e=>setCoeff(e.target.value)} placeholder={draft.model==='cauchy'?'1.5; 0.005; 0':'0.69; 0.0047; 0.4; 0.0135; 0.9; 97.9'}/></label><label>κ<Input type="number" step="any" value={draft.kappa} onChange={e=>setDraft({...draft,kappa:+e.target.value})}/></label><div className="settings-grid"><label>От, мкм<Input type="number" step="any" value={draft.range_um?.[0]??''} onChange={e=>setDraft({...draft,range_um:[+e.target.value,draft.range_um?.[1]??.8]})}/></label><label>До, мкм<Input type="number" step="any" value={draft.range_um?.[1]??''} onChange={e=>setDraft({...draft,range_um:[draft.range_um?.[0]??.4,+e.target.value]})}/></label></div></>}
    {draft.model==='tabulated'&&<label>λ [нм] · n · κ, по строке на точку<Textarea value={table} onChange={e=>setTable(e.target.value)} placeholder={'400\t1.5\t0\n800\t1.48\t0'} rows={7}/></label>}
    {draft.model==='library'&&<div className="source-info"><BookOpen size={18}/><strong>{String(draft.source.library||'Выберите набор во вкладке библиотеки')}</strong>{draft.range_um&&<p>Диапазон: {rangeLabel(draft.range_um)}</p>}<p>{String(draft.source.comments||'')}</p>{!!draft.source.conditions&&<p>Условия: {JSON.stringify(draft.source.conditions)}</p>}{!!draft.source.properties&&<p>Свойства: {JSON.stringify(draft.source.properties)}</p>}<SourceLinks source={draft.source}/><p>Версия: {String(draft.source.version||'').slice(0,12)}</p>{!draft.source.has_kappa&&<p className="warning-text">В наборе нет κ. Для расчёта выберите прозрачное приближение или другой набор.</p>}</div>}
    {!['constant','oscillator'].includes(draft.model)&&<label className="check-row"><Checkbox checked={draft.transparent_approximation} onCheckedChange={v=>setDraft({...draft,transparent_approximation:!!v})}/>Явное приближение: считать κ = 0</label>}
    {draft.model==='oscillator'&&draft.transparent_approximation&&<label className="check-row warning-text"><Checkbox checked={draft.transparent_approximation} onCheckedChange={v=>setDraft({...draft,transparent_approximation:!!v})}/>В этом проекте включено приближение κ = 0</label>}
    <Button onClick={save}>Применить материал</Button><p className="muted">Изменения применяются ко всем слоям с этим материалом.</p></div></div></TabsContent>
   <TabsContent value="library"><form className="library-search" onSubmit={e=>{e.preventDefault();void search();}}><Input aria-label="Поиск материала" value={query} onChange={e=>setQuery(e.target.value)} placeholder="SiO2, TiO2, Ag, BK7…"/><Button type="submit" disabled={busy}>{busy?<Loader2 className="spin"/>:<Search/>}Найти</Button></form><div className="library-results">{list.map(item=><button key={item.path} onClick={()=>load(item.path)} disabled={busy}><div><strong>{item.material}</strong><span>{item.label}</span></div><small>{item.path}</small></button>)}{!busy&&!list.length&&<p className="muted">Наборы не найдены. Попробуйте химическую формулу.</p>}</div><p className="muted">refractiveindex.info · данные CC0. Выбирайте запись с подходящими условиями и диапазоном.</p></TabsContent>
  </Tabs>{error&&<div className="inline-error" role="alert">{error}</div>}
 </DialogContent></Dialog>;
}
