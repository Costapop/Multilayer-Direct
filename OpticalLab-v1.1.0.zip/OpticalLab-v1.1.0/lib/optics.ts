export type MaterialDispersion={epsilon_inf:number;oscillators:{strength:number;e0_ev:number;gamma_ev:number}[];drude?:{strength:number;gamma_ev:number}|null;gaussian_oscillators?:{amplitude:number;e0_ev:number;sigma_ev:number}[]};
export type Material={id:string;name:string;model:'constant'|'cauchy'|'sellmeier'|'tabulated'|'library'|'oscillator';n:number;kappa:number;coefficients:number[];range_um:number[]|null;table:number[][];source:Record<string,unknown>;components:Record<string,unknown>[];transparent_approximation:boolean;dispersion?:MaterialDispersion|null};
export type BuiltinMaterial={id:string;material:string;name:string;range_um:number[];model:Material['model'];source:Record<string,unknown>};
export type Layer={id:string;name:string;material_id:string;thickness:number;unit:'nm'|'um'|'mm'|'cm'|'m'};
export type PlotConfig={id:string;title:string;quantities:string[];scale:'linear'|'log';unwrapped:boolean};
export type Project={schema_version:'1.0';name:string;layers:Layer[];materials:Material[];ambient_id:string;substrate_id:string;substrate_mode:'semi_infinite_lossless';settings:{kind:'wavelength'|'spectroscopic_wavenumber'|'angular_wavenumber';unit:string;start:number;stop:number;count:number;angles:number[];refine:boolean};plots:PlotConfig[]};
export type Spectrum={angle:number;metadata:Record<string,unknown>;data:Record<string,any[]>;diagnostics:{code:string;message:string;polarization?:string;layer?:number}[][]};
export type Calculation={project:Project;spectra:Spectrum[];core_commit:string};
export type Snapshot={id:string;name:string;visible:boolean;color:string;calculation:Calculation;created:string};
export const colors=['#2468ef','#d66c32','#8b55d3','#07968b','#cc477d','#657387'];
export const quantities:Record<string,string>={Rs:'Rₛ',Rp:'Rₚ',Ts:'Tₛ',Tp:'Tₚ',As:'Aₛ',Ap:'Aₚ',R:'R непол.',T:'T непол.',A:'A непол.',psi_deg:'Ψ',delta_deg:'Δ',r_s_abs:'|rₛ|',r_p_abs:'|rₚ|',r_s_re:'Re rₛ',r_s_im:'Im rₛ',r_p_re:'Re rₚ',r_p_im:'Im rₚ',rho_re:'Re ρ',rho_im:'Im ρ',rho_abs:'|ρ|',t_tan_s_abs:'|tₛ (кас.)|',t_tan_p_abs:'|tₚ (кас.)|',t_tan_s_re:'Re tₛ (кас.)',t_tan_s_im:'Im tₛ (кас.)',t_tan_p_re:'Re tₚ (кас.)',t_tan_p_im:'Im tₚ (кас.)',r_s_arg:'arg rₛ',r_p_arg:'arg rₚ',rho_arg:'arg ρ',phase_t_s:'arg tₛ',phase_t_p:'arg tₚ'};
export const energy=(q:string)=>/^[RTA][sp]?$/.test(q);
export function mat(id:string,name:string,n:number):Material{return {id,name,n,kappa:0,model:'constant',coefficients:[],range_um:null,table:[],source:{},components:[],transparent_approximation:false,dispersion:null};}
export const demo:Project={schema_version:'1.0',name:'Брэгговское зеркало · 6 пар',ambient_id:'air',substrate_id:'glass',substrate_mode:'semi_infinite_lossless',materials:[mat('air','Воздух',1),mat('glass','Стекло · n = 1,52',1.52),mat('H','H · n = 2,10',2.1),mat('L','L · n = 1,45',1.45)],layers:Array.from({length:12},(_,i)=>({id:`layer-${i+1}`,name:`Слой ${i+1}`,material_id:i%2?'L':'H',thickness:550/(4*(i%2?1.45:2.1)),unit:'nm'})),settings:{kind:'wavelength',unit:'nm',start:400,stop:800,count:401,angles:[30],refine:false},plots:[{id:'reflection',title:'Отражение',quantities:['Rs','Rp'],scale:'linear',unwrapped:false},{id:'transmission',title:'Пропускание',quantities:['Ts','Tp'],scale:'linear',unwrapped:false}]};
export async function api(path:string,body?:unknown,method?:string){const r=await fetch(`/api/optics/${path}`,{method:method||(body?'POST':'GET'),headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});const d:any=await r.json();if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:JSON.stringify(d.detail||d));return d;}
function canonical(v:any):any{if(Array.isArray(v))return v.map(canonical);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])]));return v;}
export function fingerprint(p:Project){
 // The API fills optional dispersion defaults when returning a calculation.
 // Their omission in older saved projects does not change the optical model.
 const materials=p.materials.map(m=>({...m,dispersion:m.dispersion?{...m.dispersion,oscillators:m.dispersion.oscillators??[],drude:m.dispersion.drude??null,gaussian_oscillators:m.dispersion.gaussian_oscillators??[]}:null}));
 return JSON.stringify(canonical({...p,materials,name:'',plots:[]}));
}
export function download(content:BlobPart,name:string,type='application/json'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
