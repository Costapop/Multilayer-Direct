#!/usr/bin/env python3
"""Verify, or refit, OpticalLab's six causal dielectric presets without network.

Run with the application's .venv/bin/python. Default: verify shipped coefficients.
--refit --output-dir work/refit also writes independently regenerated coefficients.
Dependencies: NumPy, SciPy. The original run used NumPy 2.5.3 / SciPy 1.18.1.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import pathlib
import re
import sys
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.optimize import nnls
from scipy.special import dawsn

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
MATERIALS = ('SiO2', 'MgF2', 'TiO2', 'Ta2O5', 'HfO2', 'Al2O3')
HC = 1.2398419843320026  # eV um


def reference(material):
    path = ROOT / 'backend/reference_data/franta' / (material + '.yml')
    raw = path.read_bytes()
    data = np.array([[float(x) for x in line.split()]
                     for line in raw.decode().splitlines()
                     if re.match(r'^        [0-9]', line)])
    return data, hashlib.sha256(raw).hexdigest()


def gaussian_basis(energy, centers, widths):
    xm = (energy[:, None] - centers[None, :]) / widths[None, :]
    xp = (energy[:, None] + centers[None, :]) / widths[None, :]
    return (2 / np.sqrt(np.pi) * (dawsn(xp) - dawsn(xm))
            + 1j * (np.exp(-xm*xm) - np.exp(-xp*xp)))


def evaluate(wavelength, oscillators):
    energy = HC / np.asarray(wavelength)
    epsilon = np.ones(energy.shape, complex)
    for osc in oscillators:
        a, center, width = (osc[k] for k in ('amplitude', 'e0_ev', 'sigma_ev'))
        xm, xp = (energy-center)/width, (energy+center)/width
        epsilon += (2*a/np.sqrt(np.pi)*(dawsn(xp)-dawsn(xm))
                    + 1j*a*(np.exp(-xm*xm)-np.exp(-xp*xp)))
    return np.sqrt(epsilon)


def refit(material, data):
    centers = np.geomspace(.002, 150, 550)
    widths = centers * .065
    if material in ('SiO2', 'MgF2', 'Ta2O5'):
        fine = np.geomspace(.02, .22, 600)
        centers = np.r_[centers, fine]
        widths = np.r_[widths, fine*(.025 if material == 'Ta2O5' else .01)]
    wl, n, kappa = data.T
    epsilon = (n+1j*kappa)**2
    basis = gaussian_basis(HC/wl, centers, widths)
    weight = 1/np.sqrt(np.maximum(abs(epsilon), 1))
    weight *= np.where((wl >= .2) & (wl <= 25), 3, 1)
    weight_imag = weight * np.where(kappa < .001, 10, 1)
    train = np.arange(len(data)) % 2 == 0
    matrix = np.vstack([(basis.real*weight[:, None])[train],
                        (basis.imag*weight_imag[:, None])[train]])
    target = np.r_[((epsilon.real-1)*weight)[train],
                   (epsilon.imag*weight_imag)[train]]
    amplitudes, _ = nnls(matrix, target, maxiter=15000)
    keep = amplitudes > 1e-10
    return [dict(amplitude=float(a), e0_ev=float(c), sigma_ev=float(s))
            for a, c, s in zip(amplitudes[keep], centers[keep], widths[keep])]


def errors(predicted, target):
    difference = predicted-target
    return dict(max_abs_n=float(max(abs(difference.real))),
                rms_n=float(np.sqrt(np.mean(difference.real**2))),
                max_abs_kappa=float(max(abs(difference.imag))),
                rms_kappa=float(np.sqrt(np.mean(difference.imag**2))),
                point_count=len(predicted))


def validate(data, oscillators):
    wl, n, kappa = data.T
    target = n+1j*kappa
    predicted = evaluate(wl, oscillators)
    valid = (wl >= .2) & (wl <= 25)
    holdout = valid & (np.arange(len(data)) % 2 == 1)
    report = {'reference_nodes': errors(predicted[valid], target[valid]),
              'held_out_nodes': errors(predicted[holdout], target[holdout])}
    midpoint = np.sqrt(wl[:-1]*wl[1:])
    midpoint = midpoint[(midpoint >= .2) & (midpoint <= 25)]
    # Tiny source kappa values may underflow internal PCHIP slopes; harmless.
    with np.errstate(over='ignore', under='ignore', divide='ignore'):
        target_mid = (PchipInterpolator(np.log(wl), n)(np.log(midpoint))
                      + 1j*PchipInterpolator(np.log(wl), kappa)(np.log(midpoint)))
    report['midpoints_vs_pchip_reference'] = errors(evaluate(midpoint, oscillators), target_mid)
    for name, lo, hi in (('uv', .2, .4), ('visible', .4, .78),
                         ('near_ir', .78, 2.5), ('mid_ir', 2.5, 25)):
        band = (wl >= lo) & (wl <= hi)
        report[name] = errors(predicted[band], target[band])
    for category in ('reference_nodes', 'held_out_nodes', 'midpoints_vs_pchip_reference'):
        assert report[category]['max_abs_n'] <= .003, (category, 'n fit tolerance')
        assert report[category]['max_abs_kappa'] <= .003, (category, 'kappa fit tolerance')
    dense = evaluate(np.geomspace(.2, 25, 10001), oscillators)
    if not np.all(np.isfinite(dense)) or np.any(dense.real <= 0) or np.any(dense.imag < 0):
        raise AssertionError('Non-finite or non-passive dense-grid response')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--material', choices=MATERIALS, action='append')
    parser.add_argument('--refit', action='store_true')
    parser.add_argument('--output-dir', type=pathlib.Path)
    args = parser.parse_args()
    if args.refit and args.output_dir is None:
        parser.error('--refit requires --output-dir; bundled presets are never overwritten')
    if args.output_dir:
        args.output_dir.mkdir(parents=True, exist_ok=True)
    for material in args.material or MATERIALS:
        data, checksum = reference(material)
        preset = json.loads((ROOT/'backend/data'/f'{material.lower()}_franta_gaussian.json').read_text())
        assert checksum == preset['source']['reference_sha256'], 'Reference hash mismatch'
        oscillators = refit(material, data) if args.refit else preset['dispersion']['gaussian_oscillators']
        report = validate(data, oscillators)
        if not args.refit:
            for category, values in report.items():
                for key, value in values.items():
                    expected = preset['source']['fit_error'][category][key]
                    assert np.isclose(value, expected, atol=2e-11, rtol=1e-6), (material, category, key)
        if not args.refit:
            from backend.models import Material
            from backend.dispersion import core_index, dielectric_function
            model = Material.model_validate(preset)
            dense_wl = np.geomspace(.2, 25, 10001)
            expected_index = np.conjugate(evaluate(dense_wl, oscillators))
            engine_index = core_index(dense_wl, model.dispersion)
            assert np.max(abs(engine_index-expected_index)) < 2e-12, 'Backend formula mismatch'
            assert abs(dielectric_function(np.array([1e8]), model.dispersion)[0]-1) < 1e-6, 'High-frequency limit / epsilon infinity'
        result = dict(material=material, reference_sha256=checksum,
                      dispersion=dict(epsilon_inf=1.0, gaussian_oscillators=oscillators),
                      range_um=[.2, 25.0], fit_error=report)
        if args.output_dir:
            (args.output_dir/f'{material.lower()}_refit.json').write_text(json.dumps(result, indent=2)+'\n')
        e = report['reference_nodes']
        print(f"{material}: {len(oscillators)} Gaussian terms; "
              f"max |Δn|={e['max_abs_n']:.7g}; max |Δκ|={e['max_abs_kappa']:.7g}; "
              f"{report['held_out_nodes']['point_count']} held-out nodes; passive dense grid")


if __name__ == '__main__':
    main()
