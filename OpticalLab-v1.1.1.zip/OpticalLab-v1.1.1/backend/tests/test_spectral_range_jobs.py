"""Range changes must create spectra on the requested, current physical grid."""
import copy
import time
import unittest

import numpy as np
from fastapi.testclient import TestClient

from backend.app import app
from backend.models import Dispersion, LayerInput, LorentzOscillator, Material, demo_project


class SpectralRangeJobTests(unittest.TestCase):
    def setUp(self):
        self.client = TestClient(app)
        self.project = demo_project()
        self.project.materials.append(Material(
            id='range-film', name='Causal test film', model='oscillator',
            range_um=[.2, 25], dispersion=Dispersion(
                epsilon_inf=2.3,
                oscillators=[LorentzOscillator(strength=12., e0_ev=5.1, gamma_ev=.3)],
            ),
        ))
        self.project.layers = [LayerInput(id='film', material_id='range-film', thickness=117)]
        self.project.settings.angles = [0]

    def run_job(self, **settings):
        for name, value in settings.items():
            setattr(self.project.settings, name, value)
        response = self.client.post('/jobs', json=self.project.model_dump())
        self.assertEqual(response.status_code, 200, response.text)
        jid = response.json()['id']
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            job = self.client.get('/jobs/' + jid).json()
            if job['status'] not in ('queued', 'running'):
                self.assertEqual(job['status'], 'done', job.get('error'))
                return jid, job['result']
            time.sleep(.005)
        self.fail('The spectral calculation did not finish')

    def assert_current_spectrum(self, result, refined=False):
        settings = self.project.settings.model_dump()
        self.assertEqual(result['project']['settings'], settings)
        spectrum = result['spectra'][0]
        data = spectrum['data']
        coordinate = np.asarray(data['coordinate'])
        self.assertEqual(coordinate[0], settings['start'])
        self.assertEqual(coordinate[-1], settings['stop'])
        self.assertTrue(np.all(np.diff(coordinate) > 0))
        if refined:
            self.assertGreaterEqual(len(coordinate), settings['count'])
            self.assertIn('refinement', spectrum['metadata'])
        else:
            np.testing.assert_array_equal(
                coordinate, np.linspace(settings['start'], settings['stop'], settings['count'])
            )
        self.assertEqual(spectrum['metadata']['coordinate_kind'], settings['kind'])
        self.assertEqual(spectrum['metadata']['coordinate_unit'], settings['unit'])

        # Explicit physical conversions, independent of the solver's to_k helper.
        if settings['kind'] == 'wavelength':
            wavelength = coordinate * (1e-3 if settings['unit'] == 'nm' else 1)
        elif settings['kind'] == 'spectroscopic_wavenumber':
            wavelength = 1e4 / coordinate  # coordinate is in cm^-1
        else:
            wavelength = 2 * np.pi / coordinate  # coordinate is in rad/um
        np.testing.assert_allclose(data['lambda_um'], wavelength, rtol=2e-15)
        np.testing.assert_allclose(data['k_rad_per_um'], 2*np.pi/wavelength, rtol=2e-15)

        # Closed-form, normal-incidence Air / absorbing Lorentz film / glass.
        # This does not call the production index or scattering implementation.
        energy = 1.2398419843320026 / wavelength
        index = np.sqrt(2.3 + 12 / (5.1**2 - energy**2 - .3j*energy)).conjugate()
        substrate = 1.52
        r01 = (1-index)/(1+index)
        r12 = (index-substrate)/(index+substrate)
        phase = np.exp(-2j*np.pi*index*.117/wavelength)
        denominator = 1+r01*r12*phase**2
        reflection = np.abs((r01+r12*phase**2)/denominator)**2
        transmission = substrate*np.abs(4*index*phase/((1+index)*(index+substrate)*denominator))**2
        for suffix in ('s', 'p', ''):
            np.testing.assert_allclose(data['R'+suffix], reflection, rtol=2e-10, atol=2e-12)
            np.testing.assert_allclose(data['T'+suffix], transmission, rtol=2e-10, atol=2e-12)
            np.testing.assert_allclose(data['A'+suffix], 1-reflection-transmission, atol=2e-12)

    def test_sequential_ranges_counts_and_coordinate_units(self):
        # The first two requests have the same array size but different endpoints;
        # the latter requests change units and cross the solver's chunk boundary.
        requests = [
            dict(kind='wavelength', unit='nm', start=400, stop=800, count=17),
            dict(kind='wavelength', unit='nm', start=850, stop=1500, count=17),
            dict(kind='wavelength', unit='um', start=.24, stop=.36, count=23),
            dict(kind='spectroscopic_wavenumber', unit='cm^-1', start=1000, stop=2500, count=257),
            dict(kind='angular_wavenumber', unit='rad/um', start=2*np.pi/.65, stop=2*np.pi/.31, count=29),
        ]
        completed = []
        for settings in requests:
            with self.subTest(settings=settings):
                jid, result = self.run_job(**settings)
                self.assert_current_spectrum(result)
                completed.append((jid, copy.deepcopy(result)))
        for jid, original in completed:
            self.assertEqual(self.client.get('/jobs/'+jid).json()['result'], original)
        self.assertNotEqual(completed[0][1]['spectra'][0]['data']['Rs'],
                            completed[1][1]['spectra'][0]['data']['Rs'])

    def test_refinement_keeps_changed_endpoints_and_current_values(self):
        for settings in [
            dict(kind='wavelength', unit='nm', start=270, stop=900, count=7),
            dict(kind='spectroscopic_wavenumber', unit='cm^-1', start=5000, stop=20000, count=9),
        ]:
            with self.subTest(settings=settings):
                _, result = self.run_job(**settings, refine=True)
                self.assert_current_spectrum(result, refined=True)

    def test_invalid_range_cannot_replace_a_completed_job(self):
        jid, original = self.run_job(kind='wavelength', unit='nm', start=400, stop=800, count=11)
        self.project.settings.start = 150  # Below the material's 200 nm limit.
        response = self.client.post('/jobs', json=self.project.model_dump())
        self.assertEqual(response.status_code, 422)
        self.assertIn('диапазон', response.json()['detail'])
        self.assertEqual(self.client.get('/jobs/'+jid).json()['result'], original)
        _, corrected = self.run_job(start=220, stop=500)
        self.assert_current_spectrum(corrected)


if __name__ == '__main__':
    unittest.main()
