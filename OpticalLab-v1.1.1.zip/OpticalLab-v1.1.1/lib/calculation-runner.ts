import type {Calculation, Project} from './optics';

type Api = (path:string, body?:unknown, method?:string) => Promise<unknown>;
type JobState = {
  status:'queued'|'running'|'done'|'error'|'cancelled';
  progress:number;
  result?:Calculation;
  error?:string;
};

export type CalculationRunnerOptions = {
  api:Api;
  onStart:() => void;
  onProgress:(percent:number) => void;
  onResult:(result:Calculation) => void;
  onError:(message:string) => void;
  onFinish:() => void;
  delay?:(milliseconds:number) => Promise<void>;
};

/** Keeps only the current submission entitled to update the displayed result. */
export function createCalculationRunner(options:CalculationRunnerOptions) {
  const delay = options.delay ?? (ms => new Promise<void>(resolve => setTimeout(resolve, ms)));
  let active:{id:string|null}|null = null;

  function deleteJob(id:string) {
    // Cancellation is best effort, including when the start response arrives late.
    try { void options.api(`jobs/${id}`, undefined, 'DELETE').catch(() => {}); }
    catch { /* A failed cancellation must not replace the current result or error. */ }
  }

  function invalidate(finish:boolean) {
    const previous = active;
    active = null;
    if (previous?.id) deleteJob(previous.id);
    if (previous && finish) options.onFinish();
  }

  async function run(project:Project):Promise<Calculation|null> {
    invalidate(false);
    // Object identity is a generation token, even before a server job ID exists.
    const submission:{id:string|null} = {id:null};
    active = submission;
    const current = () => active === submission;
    try {
      const submittedProject = structuredClone(project);
      options.onStart();
      if (!current()) return null;
      const job = await options.api('jobs', submittedProject) as {id:string};
      if (!job?.id) throw Error('Сервер не вернул идентификатор расчёта');
      if (!current()) {
        deleteJob(job.id);
        return null;
      }
      submission.id = job.id;
      while (current()) {
        const state = await options.api(`jobs/${job.id}`) as JobState;
        if (!current()) return null;
        if (Number.isFinite(state.progress)) options.onProgress(Math.max(0, Math.min(100, state.progress * 100)));
        if (!current()) return null;
        if (state.status === 'done') {
          if (!state.result) throw Error('Сервер не вернул результат расчёта');
          options.onResult(state.result);
          return state.result;
        }
        if (state.status === 'error') throw Error(state.error || 'Ошибка расчёта');
        if (state.status === 'cancelled') return null;
        if (state.status !== 'queued' && state.status !== 'running') throw Error('Неизвестное состояние расчёта');
        await delay(250);
      }
      return null;
    } catch (error) {
      if (current()) options.onError(error instanceof Error ? error.message : String(error));
      return null;
    } finally {
      if (current()) {
        active = null;
        options.onFinish();
      }
    }
  }

  return {run, cancel:() => invalidate(true)};
}
