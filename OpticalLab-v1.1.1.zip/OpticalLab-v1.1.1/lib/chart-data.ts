export type ChartPoint = {x: number; y: number | null};

/** Keep each calculated grid intact; comparison spectra need not share samples. */
export function chartPoints(
  wavelengths: number[],
  valueAt: (index: number) => number | null,
  axis: string,
  breakWrappedPhase = false,
): ChartPoint[] {
  let previous: number | null = null;
  return wavelengths.map((wavelength, index) => {
    let y = valueAt(index);
    if (breakWrappedPhase && y != null && previous != null && Math.abs(y - previous) > 180) {
      previous = y;
      y = null;
    } else {
      // An undefined phase already separates the two valid segments.
      previous = y;
    }
    const x = axis === 'nm' ? wavelength * 1000
      : axis === 'um' ? wavelength
      : axis === 'cm^-1' ? 10000 / wavelength
      : 2 * Math.PI / wavelength;
    return {x, y};
  }).sort((a, b) => a.x - b.x);
}
