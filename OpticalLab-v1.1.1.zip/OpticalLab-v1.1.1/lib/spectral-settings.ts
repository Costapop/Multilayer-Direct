import type {Project} from './optics';

type Settings = Project['settings'];
const lengthInUm:Record<string,number> = {nm:0.001,um:1,mm:1000,cm:10000,m:1000000};

export function validateSpectralSettings(settings:Settings):void {
  if(!Number.isFinite(settings.start)||!Number.isFinite(settings.stop)||settings.start<=0||settings.stop<=settings.start)
    throw Error('Укажите положительные границы диапазона: «До» должно быть больше «От».');
  if(!Number.isInteger(settings.count)||settings.count<2||settings.count>20001)
    throw Error('Число точек должно быть целым числом от 2 до 20001.');
}

export function convertSpectralSettings(settings:Settings,kind:Settings['kind'],unit:string):Settings {
  validateSpectralSettings(settings);
  function wavelength(value:number):number {
    if(settings.kind==='wavelength')return value*lengthInUm[settings.unit];
    const oldLength=settings.unit.replace('rad/','').replace('^-1','');
    return (settings.kind==='angular_wavenumber'?2*Math.PI:1)*lengthInUm[oldLength]/value;
  }
  function coordinate(wl:number):number {
    if(kind==='wavelength')return wl/lengthInUm[unit];
    const newLength=unit.replace('rad/','').replace('^-1','');
    return (kind==='angular_wavenumber'?2*Math.PI:1)*lengthInUm[newLength]/wl;
  }
  const ends=[coordinate(wavelength(settings.start)),coordinate(wavelength(settings.stop))].sort((a,b)=>a-b);
  const converted={...settings,kind,unit,start:ends[0],stop:ends[1]};
  validateSpectralSettings(converted);
  return converted;
}
