import {spawn} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));process.chdir(root);
const url='http://localhost:5173';
const openBrowser=()=>{const cmd=process.platform==='darwin'?'open':process.platform==='win32'?'cmd':'xdg-open';const args=process.platform==='win32'?['/c','start','',url]:[url];spawn(cmd,args,{stdio:'ignore'}).on('error',()=>{});};
async function running(){try{const r=await fetch(url+'/api/optics/health',{signal:AbortSignal.timeout(2000)});return r.ok?await r.json():null;}catch{return null;}}
async function ready(){const state=await running();return state?.app_version==='1.1.1'&&state?.core_commit==='282569961aeaa70506e356f68c9068ea267903fc';}
const previous=await running();
if(previous?.core_commit&&previous.app_version!=='1.1.1'){console.error('На порту 5173 уже запущена другая версия OpticalLab. Остановите её в прежнем терминале (Ctrl+C), затем запустите v1.1.1.');process.exit(1);}
if(await ready()){console.log('OpticalLab уже работает: '+url);openBrowser();process.exit(0);}
const python=process.platform==='win32'?'.venv/Scripts/python.exe':'.venv/bin/python';
if(!existsSync(python)||!existsSync('node_modules/vinext')){console.error('Сначала установите зависимости по инструкции README.md.');process.exit(1);}
const children=[];let stopping=false;
function stop(code=0){if(stopping)return;stopping=true;children.forEach(c=>c.kill('SIGTERM'));setTimeout(()=>process.exit(code),700).unref();}
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>stop());
function run(cmd,args){const child=spawn(cmd,args,{cwd:root,stdio:'inherit',env:{...process.env,OPTICS_API_URL:'http://127.0.0.1:8765'}});children.push(child);child.on('error',e=>{console.error(e.message);stop(1);});child.on('exit',code=>{if(!stopping)stop(code||0);});}
run(python,['-m','uvicorn','backend.app:app','--host','127.0.0.1','--port','8765']);
run(process.execPath,['scripts/run-framework.mjs','dev','--hostname','127.0.0.1']);
for(let i=0;i<60&&!stopping;i++){if(await ready()){console.log('\nOpticalLab: '+url+'\nДля остановки нажмите Ctrl+C.');if(process.argv.includes('--open'))openBrowser();break;}await new Promise(r=>setTimeout(r,1000));}
