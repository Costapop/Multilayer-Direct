import assert from 'node:assert/strict';
import test from 'node:test';
import {createCalculationRunner} from '../lib/calculation-runner.ts';

function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return {promise, resolve, reject};
}

function project(start=400, stop=800) {
  return {
    schema_version:'1.0', name:'Regression', layers:[], materials:[],
    ambient_id:'air', substrate_id:'glass', substrate_mode:'semi_infinite_lossless',
    settings:{kind:'wavelength', unit:'nm', start, stop, count:401, angles:[0], refine:false},
    plots:[],
  };
}

function calculation(p) {
  return {project:structuredClone(p), spectra:[], core_commit:'test'};
}

function harness() {
  const requests = [], callbacks = [], sleeps = [];
  const runner = createCalculationRunner({
    api(path, body, method) {
      const pending = deferred();
      requests.push({path, body, method, ...pending});
      return pending.promise;
    },
    onStart:() => callbacks.push(['start']),
    onProgress:value => callbacks.push(['progress', value]),
    onResult:value => callbacks.push(['result', value]),
    onError:value => callbacks.push(['error', value]),
    onFinish:() => callbacks.push(['finish']),
    delay:() => {
      const pending = deferred();
      sleeps.push(pending);
      return pending.promise;
    },
  });
  return {...runner, requests, callbacks, sleeps};
}

const flush = () => new Promise(resolve => setImmediate(resolve));

test('normal queued/running/done calculation uses a snapshot of the submitted range', async () => {
  const h = harness(), p = project(), expected = calculation(p);
  const completion = h.run(p);
  p.settings.start = 300;
  p.settings.angles.push(45);
  assert.equal(h.requests[0].body.settings.start, 400);
  assert.deepEqual(h.requests[0].body.settings.angles, [0]);
  h.requests[0].resolve({id:'a'});
  await flush();
  h.requests[1].resolve({status:'queued', progress:0});
  await flush();
  h.sleeps[0].resolve();
  await flush();
  h.requests[2].resolve({status:'running', progress:0.4});
  await flush();
  h.sleeps[1].resolve();
  await flush();
  h.requests[3].resolve({status:'done', progress:1, result:expected});
  assert.equal(await completion, expected);
  assert.deepEqual(h.callbacks, [['start'], ['progress', 0], ['progress', 40], ['progress', 100], ['result', expected], ['finish']]);
  h.cancel();
  assert.equal(h.callbacks.length, 6);
});

test('cancelling before the start response deletes the late job without displaying it', async () => {
  const h = harness();
  const completion = h.run(project());
  h.cancel();
  h.cancel();
  h.requests[0].resolve({id:'late'});
  assert.equal(await completion, null);
  assert.deepEqual(h.requests.map(r => [r.path, r.method]), [['jobs', undefined], ['jobs/late', 'DELETE']]);
  h.requests[1].reject(Error('cleanup unavailable'));
  await flush();
  assert.deepEqual(h.callbacks, [['start'], ['finish']]);
});

test('cancelling an in-flight poll suppresses its late progress and result', async () => {
  const h = harness(), p = project();
  const completion = h.run(p);
  h.requests[0].resolve({id:'a'});
  await flush();
  h.cancel();
  assert.equal(h.requests[2].method, 'DELETE');
  h.requests[1].resolve({status:'done', progress:1, result:calculation(p)});
  assert.equal(await completion, null);
  assert.deepEqual(h.callbacks, [['start'], ['finish']]);
});

test('cancelling during the polling delay prevents another poll', async () => {
  const h = harness();
  const completion = h.run(project());
  h.requests[0].resolve({id:'a'});
  await flush();
  h.requests[1].resolve({status:'running', progress:0.25});
  await flush();
  h.cancel();
  h.sleeps[0].resolve();
  assert.equal(await completion, null);
  assert.equal(h.requests.filter(r => r.path === 'jobs/a' && !r.method).length, 1);
  assert.deepEqual(h.callbacks, [['start'], ['progress', 25], ['finish']]);
});

test('a newer spectral range wins even if the old poll completes first', async () => {
  const h = harness(), oldProject = project(), newProject = project(1000, 2000);
  const oldCompletion = h.run(oldProject);
  h.requests[0].resolve({id:'old'});
  await flush();
  const newCompletion = h.run(newProject);
  assert.deepEqual(h.requests.slice(2).map(r => [r.path, r.method]), [['jobs/old', 'DELETE'], ['jobs', undefined]]);
  h.requests[1].resolve({status:'done', progress:1, result:calculation(oldProject)});
  assert.equal(await oldCompletion, null);
  assert.deepEqual(h.callbacks, [['start'], ['start']]);
  h.requests[3].resolve({id:'new'});
  await flush();
  const expected = calculation(newProject);
  h.requests[4].resolve({status:'done', progress:1, result:expected});
  assert.equal(await newCompletion, expected);
  assert.deepEqual(h.callbacks, [['start'], ['start'], ['progress', 100], ['result', expected], ['finish']]);
});

test('late start success from a superseded run cannot disturb the new run', async () => {
  const h = harness();
  const oldCompletion = h.run(project());
  const next = project(200, 350), newCompletion = h.run(next);
  h.requests[1].resolve({id:'new'});
  await flush();
  h.requests[0].resolve({id:'late-old'});
  assert.equal(await oldCompletion, null);
  assert.equal(h.requests[3].path, 'jobs/late-old');
  assert.equal(h.requests[3].method, 'DELETE');
  const expected = calculation(next);
  h.requests[2].resolve({status:'done', progress:1, result:expected});
  assert.equal(await newCompletion, expected);
  assert.equal(h.callbacks.filter(c => c[0] === 'finish').length, 1);
});

test('stale start and poll failures cannot overwrite a newer run error or busy state', async () => {
  for (const failurePhase of ['start', 'poll']) {
    const h = harness();
    const oldCompletion = h.run(project());
    let staleRequest = h.requests[0];
    if (failurePhase === 'poll') {
      staleRequest.resolve({id:'old'});
      await flush();
      staleRequest = h.requests[1];
    }
    const newCompletion = h.run(project(1000, 2000));
    const currentStart = h.requests.at(-1);
    staleRequest.reject(Error(`old ${failurePhase} failure`));
    assert.equal(await oldCompletion, null);
    assert.deepEqual(h.callbacks, [['start'], ['start']]);
    currentStart.reject(Error('current failure'));
    assert.equal(await newCompletion, null);
    assert.deepEqual(h.callbacks, [['start'], ['start'], ['error', 'current failure'], ['finish']]);
  }
});

test('current server errors, network errors, and cancellation finish exactly once', async () => {
  for (const scenario of ['start error', 'poll error', 'server error', 'server cancellation']) {
    const h = harness(), completion = h.run(project());
    if (scenario === 'start error') h.requests[0].reject(Error('request failed'));
    else {
      h.requests[0].resolve({id:'a'});
      await flush();
      if (scenario === 'poll error') h.requests[1].reject(Error('request failed'));
      if (scenario === 'server error') h.requests[1].resolve({status:'error', progress:0, error:'range rejected'});
      if (scenario === 'server cancellation') h.requests[1].resolve({status:'cancelled', progress:0});
    }
    assert.equal(await completion, null);
    assert.equal(h.callbacks.filter(c => c[0] === 'finish').length, 1);
    assert.deepEqual(h.callbacks.filter(c => c[0] === 'error'), scenario === 'server cancellation' ? [] : [['error', scenario === 'server error' ? 'range rejected' : 'request failed']]);
  }
});
