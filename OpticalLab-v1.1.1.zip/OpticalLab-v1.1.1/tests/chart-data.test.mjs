import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import test from 'node:test';
import {chartPoints} from '../lib/chart-data.ts';

const require = createRequire(import.meta.url);
const {chartDataReducer, setChartData} = require('recharts/lib/state/chartDataSlice.js');
const {combineTooltipPayload} = require('recharts/lib/state/selectors/combiners/combineTooltipPayload.js');

function tooltip(series, x, state = chartDataReducer(undefined, {type: 'test'})) {
  return combineTooltipPayload(
    series.map((data, i) => ({settings: {dataKey: 'y', name: String(i)}, dataDefinedOnItem: data})),
    '0', state, 'x', x, (data, index) => data[Number(index)], 'axis',
  ).map(entry => entry.value);
}

test('a new spectral range and sampling count replace every chart coordinate', () => {
  const oldGrid = chartPoints([.4, .6, .8], i => [1, 2, 3][i], 'nm');
  const newGrid = chartPoints([1, 1.25, 1.5, 1.75, 2], i => 10 + i, 'nm');
  assert.deepEqual(oldGrid.map(point => point.x), [400, 600, 800]);
  assert.deepEqual(newGrid, [
    {x: 1000, y: 10}, {x: 1250, y: 11}, {x: 1500, y: 12},
    {x: 1750, y: 13}, {x: 2000, y: 14},
  ]);
});

test('inverse axes retain the matching ordinate when sorted into increasing x', () => {
  assert.deepEqual(chartPoints([1, 2, 4], i => 10 + i, 'cm^-1'), [
    {x: 2500, y: 12}, {x: 5000, y: 11}, {x: 10000, y: 10},
  ]);
  assert.deepEqual(chartPoints([1, 2, 4], i => 10 + i, 'rad/um'), [
    {x: Math.PI / 2, y: 12}, {x: Math.PI, y: 11}, {x: 2 * Math.PI, y: 10},
  ]);
  assert.deepEqual(chartPoints([1, 2], i => i, 'um'), [{x: 1, y: 0}, {x: 2, y: 1}]);
});

test('nulls and wrapped phase discontinuities remain breaks on the new grid', () => {
  const phases = [170, -170, -150, null, 170, -170];
  assert.deepEqual(chartPoints([1, 2, 3, 4, 5, 6], i => phases[i], 'um', true).map(p => p.y),
    [170, null, -150, null, 170, null]);
  assert.deepEqual(chartPoints([1, 2, 3], i => [170, null, -170][i], 'um', false).map(p => p.y),
    [170, null, -170]);
});

test('comparison tooltips retain the end of a longer, disjoint calculated grid', () => {
  const oldGrid = chartPoints([.4, .8], i => i + 1, 'nm');
  const newGrid = chartPoints([1, 1.25, 1.5, 1.75, 2], i => 10 + i, 'nm');
  // Reproduce the old chart-level first-series data bug in Recharts3.8.
  const clipped = chartDataReducer(undefined, setChartData(oldGrid));
  assert.deepEqual(tooltip([oldGrid, newGrid], 2000, clipped), [undefined, undefined]);
  // Charts supplies data on each Line only, leaving the global brush indices unset.
  assert.deepEqual(tooltip([oldGrid, newGrid], 2000), [undefined, 14]);
  assert.deepEqual(tooltip([newGrid, oldGrid], 2000), [14, undefined]);
});

test('comparison tooltips match numeric x, never array positions or interpolated values', () => {
  const coarse = chartPoints([.4, .6, .8], i => 20 + i, 'nm');
  const fine = chartPoints([.4, .5, .6, .7, .8], i => 100 + i, 'nm');
  assert.deepEqual(tooltip([coarse, fine], 600), [21, 102]);
  assert.deepEqual(tooltip([coarse, fine], 700), [undefined, 103]);
  assert.deepEqual(tooltip([fine], 800), [104]);
});
