import {test} from 'node:test';
import assert from 'node:assert/strict';
import {convertSpectralSettings,validateSpectralSettings} from '../lib/spectral-settings.ts';

const base={kind:'wavelength',unit:'nm',start:1000,stop:2000,count:257,angles:[0,45],refine:true};
test('changing spectral coordinates preserves an arbitrary physical interval',()=>{
  const expected=[['wavelength','um',1,2],['spectroscopic_wavenumber','cm^-1',5000,10000],['angular_wavenumber','rad/um',Math.PI,2*Math.PI]];
  for(const [kind,unit,start,stop] of expected){
    const converted=convertSpectralSettings(base,kind,unit);
    assert.equal(converted.start,start);assert.equal(converted.stop,stop);
    assert.equal(converted.count,257);assert.equal(converted.refine,true);assert.deepEqual(converted.angles,[0,45]);
    const back=convertSpectralSettings(converted,'wavelength','nm');
    assert.ok(Math.abs(back.start-base.start)<1e-10);assert.ok(Math.abs(back.stop-base.stop)<1e-10);
  }
});
test('inverse-coordinate conversion sorts endpoints and keeps the project immutable',()=>{
  const settings={...base,kind:'spectroscopic_wavenumber',unit:'cm^-1',start:400,stop:800};
  const copy=structuredClone(settings),out=convertSpectralSettings(settings,'wavelength','um');
  assert.equal(out.start,12.5);assert.equal(out.stop,25);assert.deepEqual(settings,copy);
});
test('invalid interval or sampling receives readable validation before a request',()=>{
  for(const patch of [{start:0},{start:NaN},{stop:Infinity},{stop:999},{count:2.5},{count:1},{count:20002}])assert.throws(()=>validateSpectralSettings({...base,...patch}));
  assert.doesNotThrow(()=>validateSpectralSettings(base));
});
